require("dotenv").config();
const readline = require("readline");
const bcrypt = require("bcryptjs");
const db = require("./db");
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = q => new Promise(resolve => rl.question(q, resolve));
(async () => {
  const name = (await ask("نام مالک آکادمی: ")).trim() || "Academy Owner";
  const email = (await ask("ایمیل مدیر: ")).trim().toLowerCase();
  const password = await ask("رمز شخصی مدیر (حداقل 12 کاراکتر): ");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("ایمیل معتبر نیست.");
  if (password.length < 12) throw new Error("رمز باید حداقل 12 کاراکتر باشد.");
  const hash = await bcrypt.hash(password, 12);
  const old = db.prepare("SELECT id FROM users WHERE role='owner' LIMIT 1").get();
  if (old) db.prepare("UPDATE users SET name=?, email=?, password_hash=?, active=1 WHERE id=?").run(name,email,hash,old.id);
  else db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'owner')").run(name,email,hash);
  console.log("حساب مالک با موفقیت تنظیم شد. رمز در پایگاه داده به‌صورت هش ذخیره شده است.");
  rl.close(); db.close();
})().catch(e => { console.error(e.message); rl.close(); process.exit(1); });
