const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");
const file = path.resolve(process.env.DATABASE_FILE || "./storage/academy.sqlite");
fs.mkdirSync(path.dirname(file), { recursive: true });
const db = new Database(file);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'student',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS courses (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT DEFAULT '',
 price INTEGER NOT NULL DEFAULT 0, published INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS chapters (
 id INTEGER PRIMARY KEY AUTOINCREMENT, course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
 title TEXT NOT NULL, sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS lessons (
 id INTEGER PRIMARY KEY AUTOINCREMENT, chapter_id INTEGER NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
 title TEXT NOT NULL, description TEXT DEFAULT '', video_path TEXT DEFAULT '', video_url TEXT DEFAULT '',
 duration_seconds INTEGER DEFAULT 0, is_free INTEGER NOT NULL DEFAULT 0, sort_order INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS enrollments (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE, status TEXT NOT NULL DEFAULT 'active',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(user_id, course_id)
);
CREATE TABLE IF NOT EXISTS progress (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 lesson_id INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
 seconds_watched INTEGER NOT NULL DEFAULT 0, completed INTEGER NOT NULL DEFAULT 0,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(user_id, lesson_id)
);
CREATE TABLE IF NOT EXISTS submissions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 lesson_id INTEGER NOT NULL REFERENCES lessons(id) ON DELETE CASCADE, file_path TEXT NOT NULL,
 note TEXT DEFAULT '', grade REAL, feedback TEXT DEFAULT '', submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS announcements (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL,
 created_by INTEGER REFERENCES users(id), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 title TEXT NOT NULL, body TEXT NOT NULL, read_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS coupons (
 id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, percent_off INTEGER NOT NULL,
 expires_at TEXT, max_uses INTEGER, uses INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS payments (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
 course_id INTEGER NOT NULL REFERENCES courses(id), amount INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending', provider_ref TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS activity (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
 action TEXT NOT NULL, detail TEXT DEFAULT '', ip TEXT DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);
module.exports = db;

// Seed the six existing curriculum tracks from the original AradKlantar source.
function seedInitialCourses() {
  const count = db.prepare("SELECT COUNT(*) AS n FROM courses").get().n;
  if (count > 0) return;
  const courses = require("./seed-courses.json");
  const insertCourse = db.prepare("INSERT INTO courses(title,description,price,published) VALUES(?,?,0,1)");
  const insertChapter = db.prepare("INSERT INTO chapters(course_id,title,sort_order) VALUES(?,?,?)");
  const insertLesson = db.prepare("INSERT INTO lessons(chapter_id,title,description,video_url,duration_seconds,is_free,sort_order) VALUES(?,?,?,'',0,0,?)");
  const seed = db.transaction(() => {
    for (const course of courses) {
      const courseId = insertCourse.run(course.name, `${course.level} — ${course.description}`).lastInsertRowid;
      const lessons = course.lessons || [];
      for (let offset = 0, chapterIndex = 0; offset < lessons.length; offset += 5, chapterIndex += 1) {
        const chapterId = insertChapter.run(courseId, `بخش ${chapterIndex + 1}`, chapterIndex).lastInsertRowid;
        lessons.slice(offset, offset + 5).forEach((lesson, index) => {
          const [title, explanation, example] = lesson;
          const description = `${explanation || ""}${example ? "\n\nنمونه کد:\n" + example : ""}`;
          insertLesson.run(chapterId, title, description, offset + index);
        });
      }
    }
  });
  seed();
}
seedInitialCourses();
