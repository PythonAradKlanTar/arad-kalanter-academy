require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const {S3Client,PutObjectCommand,GetObjectCommand}=require("@aws-sdk/client-s3");
const db = require("./db");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = path.resolve(__dirname, "..");
const UPLOADS = path.resolve(process.env.UPLOAD_DIR || "./storage/uploads");
const BACKUPS = path.resolve(process.env.BACKUP_DIR || "./storage/backups");
fs.mkdirSync(UPLOADS, {recursive:true});
fs.mkdirSync(BACKUPS, {recursive:true});
const useObjectStorage=!!(process.env.R2_ACCOUNT_ID&&process.env.R2_ACCESS_KEY_ID&&process.env.R2_SECRET_ACCESS_KEY&&process.env.R2_BUCKET);
const objectStore=useObjectStorage?new S3Client({region:"auto",endpoint:`https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,credentials:{accessKeyId:process.env.R2_ACCESS_KEY_ID,secretAccessKey:process.env.R2_SECRET_ACCESS_KEY}}):null;
async function streamObject(key,res,range){const obj=await objectStore.send(new GetObjectCommand({Bucket:process.env.R2_BUCKET,Key:key,Range:range}));if(obj.ContentType)res.type(obj.ContentType);if(obj.ContentLength)res.set("Content-Length",String(obj.ContentLength));if(obj.ContentRange){res.status(206);res.set("Content-Range",obj.ContentRange);}obj.Body.pipe(res);}
if (process.env.NODE_ENV === "production" && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32 || process.env.SESSION_SECRET.includes("CHANGE_THIS"))) {
  throw new Error("Set SESSION_SECRET to a strong random value of at least 32 characters before production startup.");
}
app.disable("x-powered-by");
if (process.env.NODE_ENV === "production") app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:false, limit:"1mb"}));
app.use((req,res,next)=>{
  if(["POST","PUT","PATCH","DELETE"].includes(req.method) && req.headers.origin){
    try{if(new URL(req.headers.origin).host!==req.headers.host)return res.status(403).json({error:"درخواست بین‌سایتی رد شد."});}
    catch{return res.status(403).json({error:"مبدأ درخواست نامعتبر است."});}
  }
  next();
});
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: path.resolve("./storage") }),
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret-before-deploying",
  resave:false, saveUninitialized:false,
  cookie:{ httpOnly:true, sameSite:"lax", secure:process.env.NODE_ENV==="production", maxAge:8*60*60*1000 }
}));
const loginLimiter = rateLimit({windowMs:15*60*1000, limit:8, standardHeaders:true, legacyHeaders:false});
const log = (user, action, detail="", req=null) => db.prepare(
  "INSERT INTO activity(user_id,action,detail,ip) VALUES(?,?,?,?)"
).run(user?.id || null, action, String(detail).slice(0,500), req?.ip || "");
const safeUser = u => ({id:u.id,name:u.name,email:u.email,role:u.role});
function auth(req,res,next){ if(!req.session.user) return res.status(401).json({error:"ابتدا وارد شوید."}); next(); }
function admin(req,res,next){ if(!req.session.user || !["owner","admin"].includes(req.session.user.role)) return res.status(403).json({error:"دسترسی مدیر لازم است."}); next(); }
function owner(req,res,next){ if(!req.session.user || req.session.user.role!=="owner") return res.status(403).json({error:"فقط مالک آکادمی مجاز است."}); next(); }
const videoStorage = multer.diskStorage({
 destination:(_,__,cb)=>cb(null,UPLOADS),
 filename:(_,file,cb)=>cb(null,crypto.randomUUID()+path.extname(file.originalname).toLowerCase())
});
const videoUpload = multer({storage:videoStorage,limits:{fileSize:Number(process.env.MAX_VIDEO_MB||1024)*1024*1024},
 fileFilter:(_,f,cb)=>cb(null,["video/mp4","video/webm","video/quicktime"].includes(f.mimetype))});
const fileStorage = multer.diskStorage({destination:(_,__,cb)=>cb(null,UPLOADS),filename:(_,f,cb)=>cb(null,crypto.randomUUID()+path.extname(f.originalname).toLowerCase())});
const assignmentUpload = multer({storage:fileStorage,limits:{fileSize:Number(process.env.MAX_SUBMISSION_MB||30)*1024*1024},
 fileFilter:(_,f,cb)=>cb(null,["application/pdf","image/png","image/jpeg","application/zip","text/plain","text/x-python","text/javascript","application/javascript","text/html","text/css","application/json","application/vnd.openxmlformats-officedocument.wordprocessingml.document"].includes(f.mimetype))});

app.get("/api/health",(_,res)=>res.json({ok:true,service:"ARAD KALANTER ACADEMY"}));
app.post("/api/auth/register",loginLimiter,async(req,res)=>{
 const name=String(req.body?.name||"").trim();
 const email=String(req.body?.email||"").trim().toLowerCase();
 const password=String(req.body?.password||"");
 if(!name||! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||password.length<10) return res.status(400).json({error:"نام، ایمیل معتبر و رمز حداقل ۱۰ کاراکتری لازم است."});
 try{
  const hash=await bcrypt.hash(password,12);
  const info=db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'student')").run(name.slice(0,100),email,hash);
  const u=db.prepare("SELECT * FROM users WHERE id=?").get(info.lastInsertRowid);
  req.session.user=safeUser(u); log(u,"register","",req); res.status(201).json({user:safeUser(u)});
 }catch(e){res.status(409).json({error:"این ایمیل قبلاً ثبت شده یا اطلاعات نامعتبر است."});}
});
app.post("/api/auth/login",loginLimiter,async(req,res)=>{
 const email=String(req.body?.email||"").trim().toLowerCase();
 const u=db.prepare("SELECT * FROM users WHERE email=? AND active=1").get(email);
 if(!u || !(await bcrypt.compare(String(req.body?.password||""),u.password_hash))) return res.status(401).json({error:"ایمیل یا رمز نادرست است."});
 req.session.regenerate(err=>{if(err)return res.status(500).json({error:"خطای نشست."});req.session.user=safeUser(u);log(u,"login","",req);res.json({user:safeUser(u)});});
});
app.post("/api/auth/logout",auth,(req,res)=>{log(req.session.user,"logout","",req);req.session.destroy(()=>res.json({ok:true}));});
app.get("/api/auth/me",(req,res)=>res.json({user:req.session.user||null}));
app.get("/api/courses",(req,res)=>{
 const rows=db.prepare("SELECT c.*, (SELECT COUNT(*) FROM chapters ch WHERE ch.course_id=c.id) chapter_count FROM courses c WHERE c.published=1 ORDER BY c.id DESC").all();
 res.json(rows);
});
app.get("/api/courses/:id/content",auth,(req,res)=>{
 const course=db.prepare("SELECT * FROM courses WHERE id=? AND published=1").get(req.params.id);
 if(!course)return res.status(404).json({error:"دوره پیدا نشد."});
 const enrolled=!!db.prepare("SELECT 1 FROM enrollments WHERE user_id=? AND course_id=? AND status='active'").get(req.session.user.id,course.id);
 const chapters=db.prepare("SELECT * FROM chapters WHERE course_id=? ORDER BY sort_order,id").all(course.id).map(ch=>{
  const lessons=db.prepare("SELECT id,title,description,duration_seconds,is_free,sort_order,CASE WHEN video_path!='' OR video_url!='' THEN 1 ELSE 0 END AS has_video FROM lessons WHERE chapter_id=? ORDER BY sort_order,id").all(ch.id);
  return {...ch,lessons:lessons.map(l=>({...l,locked:!enrolled&&!l.is_free}))};
 });
 res.json({course,chapters});
});
app.get("/api/lessons/:id/video",auth,async(req,res)=>{
 const l=db.prepare("SELECT l.*,ch.course_id FROM lessons l JOIN chapters ch ON ch.id=l.chapter_id WHERE l.id=?").get(req.params.id);
 if(!l)return res.status(404).json({error:"جلسه پیدا نشد."});
 const enrolled=db.prepare("SELECT 1 FROM enrollments WHERE user_id=? AND course_id=? AND status='active'").get(req.session.user.id,l.course_id);
 if(!l.is_free&&!enrolled&&!["owner","admin"].includes(req.session.user.role))return res.status(403).json({error:"برای مشاهده این ویدئو باید در دوره ثبت‌نام کنید."});
 log(req.session.user,"watch_lesson",l.id,req);
 if(l.video_path){if(useObjectStorage){try{return await streamObject(l.video_path,res,req.headers.range);}catch{return res.status(404).json({error:"فایل ویدئو موجود نیست."});}}const file=path.join(UPLOADS,path.basename(l.video_path));if(!fs.existsSync(file))return res.status(404).json({error:"فایل ویدئو موجود نیست."});return res.sendFile(file);}
 if(l.video_url)return res.redirect(302,l.video_url);
 res.status(404).json({error:"برای این جلسه ویدئویی ثبت نشده است."});
});
app.post("/api/progress",auth,(req,res)=>{
 const {lessonId,secondsWatched,completed}=req.body||{};
 if(!Number.isInteger(Number(lessonId)))return res.status(400).json({error:"شناسه درس نامعتبر است."});
 const lesson=db.prepare("SELECT l.is_free,ch.course_id FROM lessons l JOIN chapters ch ON ch.id=l.chapter_id WHERE l.id=?").get(Number(lessonId));
 if(!lesson)return res.status(404).json({error:"درس پیدا نشد."});
 const enrolled=db.prepare("SELECT 1 FROM enrollments WHERE user_id=? AND course_id=? AND status='active'").get(req.session.user.id,lesson.course_id);
 if(!lesson.is_free&&!enrolled&&!['owner','admin'].includes(req.session.user.role))return res.status(403).json({error:"برای ثبت پیشرفت باید در دوره ثبت‌نام کنید."});
 db.prepare(`INSERT INTO progress(user_id,lesson_id,seconds_watched,completed,updated_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)
 ON CONFLICT(user_id,lesson_id) DO UPDATE SET seconds_watched=MAX(progress.seconds_watched,excluded.seconds_watched),completed=MAX(progress.completed,excluded.completed),updated_at=CURRENT_TIMESTAMP`)
 .run(req.session.user.id,Number(lessonId),Math.max(0,Number(secondsWatched)||0),completed?1:0);
 log(req.session.user,"progress",lessonId,req);res.json({ok:true});
});
app.get("/api/my/progress",auth,(req,res)=>res.json(db.prepare("SELECT p.*,l.title lesson_title FROM progress p JOIN lessons l ON l.id=p.lesson_id WHERE p.user_id=? ORDER BY p.updated_at DESC").all(req.session.user.id)));
app.post("/api/admin/courses",admin,(req,res)=>{
 const {title,description,price,published}=req.body||{};
 if(!title)return res.status(400).json({error:"عنوان دوره الزامی است."});
 const r=db.prepare("INSERT INTO courses(title,description,price,published) VALUES(?,?,?,?)").run(title,description||"",Math.max(0,Number(price)||0),published?1:0);
 log(req.session.user,"create_course",r.lastInsertRowid,req);res.status(201).json({id:r.lastInsertRowid});
});
app.get("/api/admin/courses",admin,(req,res)=>res.json(db.prepare("SELECT * FROM courses ORDER BY id DESC").all()));

app.get("/api/admin/courses/:id/outline",admin,(req,res)=>{
 const course=db.prepare("SELECT * FROM courses WHERE id=?").get(req.params.id);
 if(!course)return res.status(404).json({error:"دوره پیدا نشد."});
 const chapters=db.prepare("SELECT * FROM chapters WHERE course_id=? ORDER BY sort_order,id").all(course.id).map(ch=>({
  ...ch,
  lessons:db.prepare("SELECT id,title,description,duration_seconds,is_free,sort_order,CASE WHEN video_path!='' OR video_url!='' THEN 1 ELSE 0 END AS has_video FROM lessons WHERE chapter_id=? ORDER BY sort_order,id").all(ch.id)
 }));
 res.json({course,chapters});
});
app.post("/api/courses/:id/enroll",auth,(req,res)=>{
 const course=db.prepare("SELECT * FROM courses WHERE id=? AND published=1").get(req.params.id);
 if(!course)return res.status(404).json({error:"دوره پیدا نشد."});
 if(course.price>0)return res.status(402).json({error:"این دوره پولی است؛ ابتدا باید درگاه پرداخت واقعی به سایت متصل شود."});
 try{
  const result=db.prepare("INSERT INTO enrollments(user_id,course_id,status) VALUES(?,?,'active')").run(req.session.user.id,course.id);
  log(req.session.user,"free_enrollment",course.id,req);
  res.status(201).json({ok:true,enrollmentId:result.lastInsertRowid});
 }catch(error){res.status(409).json({error:"شما قبلاً در این دوره ثبت‌نام شده‌اید."});}
});
app.get("/api/my/enrollments",auth,(req,res)=>res.json(db.prepare("SELECT e.*,c.title,c.description,c.price FROM enrollments e JOIN courses c ON c.id=e.course_id WHERE e.user_id=? AND e.status='active' ORDER BY e.id DESC").all(req.session.user.id)));

app.put("/api/admin/courses/:id",admin,(req,res)=>{
 const {title,description,price,published}=req.body||{};
 db.prepare("UPDATE courses SET title=?,description=?,price=?,published=? WHERE id=?").run(title,description||"",Math.max(0,Number(price)||0),published?1:0,req.params.id);
 log(req.session.user,"update_course",req.params.id,req);res.json({ok:true});
});
app.delete("/api/admin/courses/:id",admin,(req,res)=>{db.prepare("DELETE FROM courses WHERE id=?").run(req.params.id);log(req.session.user,"delete_course",req.params.id,req);res.json({ok:true});});
app.post("/api/admin/courses/:id/chapters",admin,(req,res)=>{
 const r=db.prepare("INSERT INTO chapters(course_id,title,sort_order) VALUES(?,?,?)").run(req.params.id,req.body.title,Number(req.body.sortOrder)||0);
 log(req.session.user,"create_chapter",r.lastInsertRowid,req);res.status(201).json({id:r.lastInsertRowid});
});
app.put("/api/admin/chapters/:id",admin,(req,res)=>{db.prepare("UPDATE chapters SET title=?,sort_order=? WHERE id=?").run(req.body.title,Number(req.body.sortOrder)||0,req.params.id);res.json({ok:true});});
app.patch("/api/admin/chapters/:id/title",admin,(req,res)=>{db.prepare("UPDATE chapters SET title=? WHERE id=?").run(String(req.body.title||"").slice(0,160),req.params.id);res.json({ok:true});});
app.delete("/api/admin/chapters/:id",admin,(req,res)=>{db.prepare("DELETE FROM chapters WHERE id=?").run(req.params.id);res.json({ok:true});});
app.post("/api/admin/chapters/:id/lessons",admin,(req,res)=>{
 const r=db.prepare("INSERT INTO lessons(chapter_id,title,description,video_url,duration_seconds,is_free,sort_order) VALUES(?,?,?,?,?,?,?)")
 .run(req.params.id,req.body.title,req.body.description||"",req.body.videoUrl||"",Number(req.body.durationSeconds)||0,req.body.isFree?1:0,Number(req.body.sortOrder)||0);
 log(req.session.user,"create_lesson",r.lastInsertRowid,req);res.status(201).json({id:r.lastInsertRowid});
});
app.post("/api/admin/lessons/:id/video",admin,videoUpload.single("video"),async(req,res,next)=>{
 try {
  if(!req.file)return res.status(400).json({error:"فایل MP4/WebM/MOV معتبر انتخاب کنید."});
  const key=`videos/${req.file.filename}`;
  let storedName=req.file.filename;
  if(useObjectStorage){
   await objectStore.send(new PutObjectCommand({Bucket:process.env.R2_BUCKET,Key:key,Body:fs.createReadStream(req.file.path),ContentType:req.file.mimetype}));
   fs.unlinkSync(req.file.path);
   storedName=key;
  }
  db.prepare("UPDATE lessons SET video_path=?,video_url='' WHERE id=?").run(storedName,req.params.id);
  log(req.session.user,"upload_video",req.params.id,req);
  res.status(201).json({ok:true,filename:req.file.filename,storage:useObjectStorage?"R2":"server-disk"});
 } catch(error){next(error);}
});
app.put("/api/admin/lessons/:id",admin,(req,res)=>{
 const b=req.body||{};
 db.prepare("UPDATE lessons SET title=?,description=?,video_url=?,duration_seconds=?,is_free=?,sort_order=? WHERE id=?")
 .run(b.title,b.description||"",b.videoUrl||"",Number(b.durationSeconds)||0,b.isFree?1:0,Number(b.sortOrder)||0,req.params.id);
 res.json({ok:true});
});
app.patch("/api/admin/lessons/:id/title",admin,(req,res)=>{db.prepare("UPDATE lessons SET title=? WHERE id=?").run(String(req.body.title||"").slice(0,160),req.params.id);res.json({ok:true});});
app.delete("/api/admin/lessons/:id",admin,(req,res)=>{db.prepare("DELETE FROM lessons WHERE id=?").run(req.params.id);res.json({ok:true});});
app.post("/api/lessons/:id/submit",auth,assignmentUpload.single("file"),(req,res)=>{
 if(!req.file)return res.status(400).json({error:"فایل مجاز انتخاب کنید."});
 const lesson=db.prepare("SELECT l.is_free,ch.course_id FROM lessons l JOIN chapters ch ON ch.id=l.chapter_id WHERE l.id=?").get(req.params.id);
 if(!lesson)return res.status(404).json({error:"درس پیدا نشد."});
 const enrolled=db.prepare("SELECT 1 FROM enrollments WHERE user_id=? AND course_id=? AND status='active'").get(req.session.user.id,lesson.course_id);
 if(!lesson.is_free&&!enrolled&&!['owner','admin'].includes(req.session.user.role))return res.status(403).json({error:"برای ارسال تکلیف باید در دوره ثبت‌نام کنید."});
 const r=db.prepare("INSERT INTO submissions(user_id,lesson_id,file_path,note) VALUES(?,?,?,?)").run(req.session.user.id,req.params.id,req.file.filename,String(req.body.note||"").slice(0,2000));
 log(req.session.user,"submit_assignment",r.lastInsertRowid,req);res.status(201).json({id:r.lastInsertRowid});
});
app.get("/api/admin/submissions",admin,(req,res)=>res.json(db.prepare("SELECT s.*,u.name student_name,u.email,l.title lesson_title FROM submissions s JOIN users u ON u.id=s.user_id JOIN lessons l ON l.id=s.lesson_id ORDER BY s.submitted_at DESC").all()));
app.get("/api/admin/submissions/:id/file",admin,(req,res)=>{
 const row=db.prepare("SELECT file_path FROM submissions WHERE id=?").get(req.params.id);
 if(!row)return res.sendStatus(404);
 const file=path.join(UPLOADS,path.basename(row.file_path));
 if(!fs.existsSync(file))return res.sendStatus(404);
 res.download(file);
});
app.put("/api/admin/submissions/:id/grade",admin,(req,res)=>{
 db.prepare("UPDATE submissions SET grade=?,feedback=? WHERE id=?").run(Number(req.body.grade),String(req.body.feedback||"").slice(0,2000),req.params.id);
 res.json({ok:true});
});
app.get("/api/admin/users",admin,(req,res)=>res.json(db.prepare("SELECT id,name,email,role,active,created_at FROM users ORDER BY created_at DESC").all()));
app.put("/api/admin/users/:id/role",owner,(req,res)=>{
 if(!["student","admin"].includes(req.body.role))return res.status(400).json({error:"نقش نامعتبر است."});
 if(Number(req.params.id)===req.session.user.id)return res.status(400).json({error:"نقش مالک اصلی قابل تغییر نیست."});
 db.prepare("UPDATE users SET role=? WHERE id=? AND role!='owner'").run(req.body.role,req.params.id);res.json({ok:true});
});
app.put("/api/admin/users/:id/active",admin,(req,res)=>{db.prepare("UPDATE users SET active=? WHERE id=? AND role!='owner'").run(req.body.active?1:0,req.params.id);res.json({ok:true});});
app.post("/api/admin/announcements",admin,(req,res)=>{
 const r=db.prepare("INSERT INTO announcements(title,body,created_by) VALUES(?,?,?)").run(req.body.title,req.body.body,req.session.user.id);
 const students=db.prepare("SELECT id FROM users WHERE role='student' AND active=1").all();
 const add=db.prepare("INSERT INTO messages(user_id,title,body) VALUES(?,?,?)");
 const tx=db.transaction(()=>students.forEach(s=>add.run(s.id,req.body.title,req.body.body)));tx();
 log(req.session.user,"announcement",r.lastInsertRowid,req);res.status(201).json({id:r.lastInsertRowid,recipients:students.length});
});
app.get("/api/announcements",(req,res)=>res.json(db.prepare("SELECT id,title,body,created_at FROM announcements ORDER BY id DESC LIMIT 50").all()));
app.get("/api/my/messages",auth,(req,res)=>res.json(db.prepare("SELECT * FROM messages WHERE user_id=? ORDER BY id DESC").all(req.session.user.id)));
app.put("/api/my/messages/:id/read",auth,(req,res)=>{db.prepare("UPDATE messages SET read_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?").run(req.params.id,req.session.user.id);res.json({ok:true});});
app.post("/api/admin/coupons",admin,(req,res)=>{
 const {code,percentOff,expiresAt,maxUses}=req.body||{};
 if(!code||Number(percentOff)<1||Number(percentOff)>90)return res.status(400).json({error:"کد و درصد تخفیف ۱ تا ۹۰ لازم است."});
 try{const r=db.prepare("INSERT INTO coupons(code,percent_off,expires_at,max_uses) VALUES(?,?,?,?)").run(String(code).toUpperCase(),Number(percentOff),expiresAt||null,maxUses?Number(maxUses):null);res.status(201).json({id:r.lastInsertRowid});}
 catch(e){res.status(409).json({error:"این کد قبلاً وجود دارد."});}
});
app.get("/api/admin/coupons",admin,(req,res)=>res.json(db.prepare("SELECT * FROM coupons ORDER BY id DESC").all()));
app.post("/api/coupons/validate",auth,(req,res)=>{
 const c=db.prepare("SELECT * FROM coupons WHERE code=? AND active=1").get(String(req.body.code||"").toUpperCase());
 if(!c|| (c.expires_at&&new Date(c.expires_at)<new Date()) || (c.max_uses&&c.uses>=c.max_uses))return res.status(404).json({error:"کد تخفیف معتبر نیست."});
 res.json({code:c.code,percentOff:c.percent_off});
});
app.get("/api/admin/reports",admin,(req,res)=>{
 const scalar=q=>db.prepare(q).get().n;
 res.json({
  students:scalar("SELECT COUNT(*) n FROM users WHERE role='student'"),
  courses:scalar("SELECT COUNT(*) n FROM courses"),
  enrollments:scalar("SELECT COUNT(*) n FROM enrollments"),
  submissions:scalar("SELECT COUNT(*) n FROM submissions"),
  recentActivity:db.prepare("SELECT a.*,u.name,u.email FROM activity a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 100").all()
 });
});
app.post("/api/admin/enrollments",admin,(req,res)=>{
 try{const r=db.prepare("INSERT INTO enrollments(user_id,course_id,status) VALUES(?,?,'active')").run(req.body.userId,req.body.courseId);res.status(201).json({id:r.lastInsertRowid});}
 catch(e){res.status(409).json({error:"ثبت‌نام قبلاً وجود دارد یا اطلاعات نامعتبر است."});}
});
app.post("/api/admin/backup",owner,(req,res)=>{
 const stamp=new Date().toISOString().replace(/[:.]/g,"-");
 const dest=path.join(BACKUPS,`manual-${stamp}`);
 fs.mkdirSync(dest,{recursive:true});
 db.backup(path.join(dest,"academy.sqlite")).then(()=>{
  if(!useObjectStorage)fs.cpSync(UPLOADS,path.join(dest,"uploads"),{recursive:true});
  log(req.session.user,"backup",path.basename(dest),req);res.json({ok:true,file:path.basename(dest)});
 }).catch(()=>res.status(500).json({error:"پشتیبان‌گیری ناموفق بود."}));
});
app.post("/api/admin/payments/start",auth,(req,res)=>{
 // Gateway integration deliberately disabled until provider, merchant account and callback verification are configured.
 if(!process.env.PAYMENT_PROVIDER||!process.env.PAYMENT_MERCHANT_ID||!process.env.PAYMENT_SECRET)
  return res.status(503).json({error:"درگاه پرداخت هنوز پیکربندی نشده است. مشخصات پذیرنده و پیاده‌سازی تأیید callback لازم است."});
 res.status(501).json({error:"آداپتور اختصاصی درگاه باید برای ارائه‌دهنده انتخابی تکمیل و آزمایش شود."});
});
app.get("/uploads/:name",auth,(req,res)=>{
 const name=path.basename(req.params.name);
 const lesson=db.prepare("SELECT l.id,l.is_free,ch.course_id FROM lessons l JOIN chapters ch ON ch.id=l.chapter_id WHERE l.video_path=?").get(name);
 if(lesson){
  const enrolled=db.prepare("SELECT 1 FROM enrollments WHERE user_id=? AND course_id=? AND status='active'").get(req.session.user.id,lesson.course_id);
  if(!lesson.is_free&&!enrolled&&!["owner","admin"].includes(req.session.user.role))return res.sendStatus(403);
 }else if(!["owner","admin"].includes(req.session.user.role))return res.sendStatus(404);
 if(useObjectStorage){return streamObject(`videos/${name}`,res).catch(()=>res.sendStatus(404));}const file=path.join(UPLOADS,name);if(!fs.existsSync(file))return res.sendStatus(404);res.sendFile(file);
});
app.use("/assets",express.static(path.join(ROOT,"assets"),{fallthrough:true}));
app.get("/manifest.webmanifest",(_,res)=>res.sendFile(path.join(ROOT,"public","manifest.webmanifest")));
app.use("/icons",express.static(path.join(ROOT,"public","icons")));
app.get("/sw.js",(_,res)=>{res.set("Service-Worker-Allowed","/");res.sendFile(path.join(ROOT,"public","sw.js"));});
app.get("/",(_,res)=>res.type("html").sendFile(path.join(ROOT,"AradKlantar")));
app.get("/index.html",(_,res)=>res.sendFile(path.join(ROOT,"index.html")));
app.get("/admin-tools",(_,res)=>res.sendFile(path.join(ROOT,"public","admin-tools.html")));
app.get("/admin-tools.js",(_,res)=>res.sendFile(path.join(ROOT,"public","admin-tools.js")));
app.get("/student-tools",(_,res)=>res.sendFile(path.join(ROOT,"public","student-tools.html")));
app.get("/student-tools.js",(_,res)=>res.sendFile(path.join(ROOT,"public","student-tools.js")));
app.use((err,req,res,next)=>{console.error(err);res.status(400).json({error:err.code==="LIMIT_FILE_SIZE"?"حجم فایل بیش از حد مجاز است.":"درخواست نامعتبر یا فایل غیرمجاز است."});});

async function dailyBackup(){
  try{
    const day=new Date().toISOString().slice(0,10);
    if(fs.existsSync(BACKUPS) && fs.readdirSync(BACKUPS).some(n=>n.startsWith(`automatic-${day}`))) return;
    const target=path.join(BACKUPS,`automatic-${day}`);
    fs.mkdirSync(target,{recursive:true});
    await db.backup(path.join(target,"academy.sqlite"));
    if(!useObjectStorage)fs.cpSync(UPLOADS,path.join(target,"uploads"),{recursive:true});
    const dirs=fs.readdirSync(BACKUPS).filter(n=>n.startsWith("automatic-")||n.startsWith("manual-")).sort();
    for(const old of dirs.slice(0,Math.max(0,dirs.length-14)))fs.rmSync(path.join(BACKUPS,old),{recursive:true,force:true});
  }catch(e){console.error("Daily backup failed:",e.message);}
}
app.listen(PORT,()=>{console.log(`ARAD Academy listening on port ${PORT}`);dailyBackup();setInterval(dailyBackup,60*60*1000);});

