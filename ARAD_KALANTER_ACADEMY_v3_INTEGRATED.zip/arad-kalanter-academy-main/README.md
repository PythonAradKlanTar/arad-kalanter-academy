# arad-kalanter-academy
ARAD KALANTER ACADEMY

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#070b18">
<title>کدنویسی و هوش مصنوعی | ARAD ACADEMY</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

<style>
:root{
 --bg:#070b18;
 --panel:rgba(17,27,49,.82);
 --border:rgba(56,189,248,.2);
 --blue:#38bdf8;
 --purple:#a855f7;
 --green:#2ef5b0;
 --white:#f1f5ff;
 --muted:#9baac7;
 --danger:#fb5275;
}

*{
 margin:0;
 padding:0;
 box-sizing:border-box;
}

html{scroll-behavior:smooth}

body{
 background:var(--bg);
 color:var(--white);
 font-family:'Vazirmatn',Tahoma,sans-serif;
 min-height:100vh;
 overflow-x:hidden;
}

button,input,textarea{font-family:inherit}
button{cursor:pointer}

#background{
 position:fixed;
 inset:0;
 z-index:-3;
 background:
 radial-gradient(ellipse at 15% 20%,rgba(56,189,248,.16),transparent 35%),
 radial-gradient(ellipse at 85% 75%,rgba(168,85,247,.17),transparent 35%),
 #070b18;
}

.grid-bg{
 position:fixed;
 inset:0;
 z-index:-2;
 pointer-events:none;
 opacity:.12;
 background-image:
 linear-gradient(rgba(56,189,248,.2) 1px,transparent 1px),
 linear-gradient(90deg,rgba(56,189,248,.2) 1px,transparent 1px);
 background-size:45px 45px;
 mask-image:linear-gradient(to bottom,black,transparent);
}

.glow{
 position:fixed;
 width:300px;
 height:300px;
 border-radius:50%;
 filter:blur(100px);
 opacity:.2;
 z-index:-1;
 pointer-events:none;
 animation:glowMove 9s infinite alternate;
}

.glow.one{
 background:#168aff;
 top:10%;
 left:-150px;
}

.glow.two{
 background:#a855f7;
 bottom:5%;
 right:-150px;
 animation-delay:2s;
}

@keyframes glowMove{
 to{transform:translate(80px,70px)}
}

header{
 position:sticky;
 top:0;
 z-index:100;
 background:rgba(7,11,24,.9);
 backdrop-filter:blur(20px);
 border-bottom:1px solid var(--border);
}

.navbar{
 max-width:1250px;
 margin:auto;
 padding:14px 22px;
 min-height:76px;
 display:flex;
 align-items:center;
 justify-content:space-between;
 gap:15px;
}

.logo{
 font-size:19px;
 font-weight:900;
 color:white;
 white-space:nowrap;
}

.logo span{
 color:var(--blue);
}

.nav-links{
 display:flex;
 align-items:center;
 gap:8px;
 flex-wrap:wrap;
}

.nav-links button{
 background:transparent;
 border:1px solid transparent;
 color:var(--muted);
 padding:9px 13px;
 border-radius:12px;
 font-size:13px;
 transition:.3s;
}

.nav-links button:hover,
.nav-links button.active{
 color:var(--blue);
 border-color:var(--border);
 background:rgba(56,189,248,.08);
}

.menu-toggle{
 display:none;
 border:1px solid var(--border);
 color:white;
 background:var(--panel);
 padding:9px 13px;
 border-radius:10px;
 font-size:20px;
}

.container{
 max-width:1200px;
 width:92%;
 margin:auto;
}

.page{
 display:none;
 animation:pageIn .4s ease;
}

.page.active{display:block}

@keyframes pageIn{
 from{opacity:0;transform:translateY(12px)}
 to{opacity:1;transform:translateY(0)}
}

.hero{
 min-height:610px;
 display:grid;
 grid-template-columns:1.1fr .9fr;
 align-items:center;
 gap:40px;
 padding:65px 0;
}

.badge{
 display:inline-block;
 padding:7px 15px;
 border:1px solid rgba(56,189,248,.3);
 background:rgba(56,189,248,.08);
 color:var(--blue);
 border-radius:30px;
 font-size:12px;
 margin-bottom:20px;
}

.hero h1{
 font-size:clamp(32px,5vw,58px);
 line-height:1.6;
 font-weight:900;
}

.gradient{
 background:linear-gradient(90deg,#38bdf8,#a855f7,#2ef5b0);
 background-clip:text;
 -webkit-background-clip:text;
 color:transparent;
}

.hero p{
 color:var(--muted);
 line-height:2.3;
 margin:18px 0;
 font-size:15px;
}

.btn{
 border:none;
 border-radius:12px;
 padding:12px 21px;
 background:linear-gradient(110deg,#168aff,#8b5cf6);
 color:white;
 font-size:14px;
 font-weight:700;
 box-shadow:0 5px 25px rgba(56,189,248,.18);
 transition:.3s;
}

.btn:hover{
 transform:translateY(-3px);
 box-shadow:0 8px 30px rgba(56,189,248,.35);
}

.btn.secondary{
 background:rgba(255,255,255,.05);
 border:1px solid var(--border);
 box-shadow:none;
}

.hero-visual{
 background:linear-gradient(145deg,rgba(30,50,85,.75),rgba(12,19,37,.9));
 border:1px solid var(--border);
 border-radius:25px;
 padding:35px;
 box-shadow:0 0 50px rgba(56,189,248,.1);
 position:relative;
 overflow:hidden;
}

.hero-visual::before{
 content:"";
 position:absolute;
 width:200px;
 height:200px;
 background:var(--purple);
 filter:blur(100px);
 opacity:.2;
 top:-70px;
 left:-60px;
}

.terminal{
 direction:ltr;
 text-align:left;
 padding:24px;
 margin-top:25px;
 background:#050a15;
 border:1px solid rgba(56,189,248,.2);
 border-radius:16px;
 font-family:monospace;
 font-size:14px;
 line-height:2.2;
 color:#b8c9e9;
 overflow-wrap:anywhere;
}

.terminal .keyword{color:#c084fc}
.terminal .string{color:#2ef5b0}
.terminal .function{color:#38bdf8}

section{padding:45px 0}

.section-title{
 text-align:center;
 margin-bottom:30px;
}

.section-title h2{
 font-size:28px;
 margin-bottom:10px;
}

.section-title p{
 color:var(--muted);
 font-size:14px;
}

.grid{
 display:grid;
 grid-template-columns:repeat(3,1fr);
 gap:20px;
}

.card,.panel,.stat{
 background:var(--panel);
 border:1px solid var(--border);
 border-radius:20px;
 padding:24px;
 backdrop-filter:blur(14px);
 transition:.3s;
}

.card:hover{
 transform:translateY(-6px);
 border-color:rgba(56,189,248,.55);
 box-shadow:0 10px 35px rgba(56,189,248,.1);
}

.card-icon{
 font-size:35px;
 margin-bottom:15px;
}

.card h3{
 font-size:18px;
 margin-bottom:10px;
}

.card p{
 color:var(--muted);
 line-height:2;
 font-size:13px;
}

.stat{
 text-align:center;
}

.stat strong{
 display:block;
 color:var(--blue);
 font-size:30px;
 margin-bottom:8px;
}

.search{
 width:100%;
 padding:15px;
 background:#101a30;
 border:1px solid var(--border);
 color:white;
 border-radius:12px;
 outline:none;
 margin-bottom:25px;
}

.search:focus{
 border-color:var(--blue);
 box-shadow:0 0 15px rgba(56,189,248,.15);
}

.progress{
 height:8px;
 background:#202c43;
 border-radius:20px;
 overflow:hidden;
 margin:15px 0;
}

.progress span{
 display:block;
 height:100%;
 background:linear-gradient(90deg,var(--blue),var(--purple));
 border-radius:20px;
}

.notice{
 color:var(--muted);
 font-size:12px;
 margin-top:15px;
}

footer{
 text-align:center;
 padding:40px 20px;
 margin-top:60px;
 border-top:1px solid var(--border);
 color:var(--muted);
 line-height:2.4;
}

footer h3{
 font-size:22px;
}

@media(max-width:850px){
 .hero{
  grid-template-columns:1fr;
  padding:45px 0;
 }

 .grid{
  grid-template-columns:repeat(2,1fr);
 }
}

@media(max-width:600px){
 .navbar{
  flex-wrap:wrap;
 }

 .menu-toggle{display:block}

 .nav-links{
  display:none;
  width:100%;
  flex-direction:column;
  align-items:stretch;
 }

 .nav-links.open{display:flex}

 .nav-links button{
  text-align:right;
  width:100%;
 }

 .hero h1{font-size:34px}

 .hero-visual{padding:22px}

 .grid{grid-template-columns:1fr}

 .section-title h2{font-size:23px}
}
</style>
</head>

<body>

<div id="background"></div>
<div class="grid-bg"></div>
<div class="glow one"></div>
<div class="glow two"></div>

<header>
 <nav class="navbar">

  <div class="logo">
   ARAD <span>ACADEMY</span>
  </div>

  <button class="menu-toggle" onclick="toggleMenu()">☰</button>

  <div class="nav-links" id="navLinks">
   <button class="active" onclick="showPage('home',this)">خانه</button>
   <button onclick="showPage('courses',this)">دوره‌ها</button>
   <button onclick="showPage('projects',this)">پروژه‌ها</button>
   <button onclick="showPage('sources',this)">دانلود سورس</button>
   <button onclick="showPage('account',this)">حساب کاربری</button>
   <button onclick="showPage('dashboard',this)">داشبورد</button>
  </div>

 </nav>
</header>

<main>

<section id="home" class="page active">

 <div class="container">

  <div class="hero">

   <div>

    <span class="badge">
     🚀 آموزش تخصصی برنامه‌نویسی و هوش مصنوعی
    </span>

    <h1>
     به دنیای
     <span class="gradient">کدنویسی</span>
     و هوش مصنوعی خوش آمدی
    </h1>

    <p>
     در آکادمی برنامه‌نویسی اراد کلانتر هرمزی،
     مهارت‌های واقعی برنامه‌نویسی را یاد بگیر،
     پروژه بساز، تمرین کن و آینده خودت را با تکنولوژی بساز.
    </p>

    <button class="btn" onclick="showPage('courses')">
     شروع یادگیری ←
    </button>

    <button class="btn secondary" onclick="showPage('account')">
     عضویت در آکادمی
    </button>

    <p class="notice">
     مسیر یادگیری از سطح مبتدی تا متخصص
    </p>

   </div>

   <div class="hero-visual">

    <span class="badge">ARAD.DEV</span>

    <h2 class="gradient">Code. Learn. Build.</h2>

    <div class="terminal">
     <span class="keyword">class</span> Academy:<br>
     &nbsp;&nbsp;<span class="keyword">def</span> learn(self):<br>
     &nbsp;&nbsp;&nbsp;&nbsp;<span class="keyword">return</span>
     <span class="string">"Your Future Starts Here"</span><br><br>

     <span class="function">print</span>
     (Academy().learn())<br><br>

     <span style="color:#2ef5b0">
      > Welcome to ARAD ACADEMY
     </span>
    </div>

    <p>آینده‌ات را با یادگیری بساز.</p>

   </div>

  </div>

  <section>
   <div class="grid">

    <div class="stat">
     <strong id="courseCount">۶+</strong>
     مسیر آموزشی
    </div>

    <div class="stat">
     <strong>۲۴/۷</strong>
     دسترسی به آموزش
    </div>

    <div class="stat">
     <strong>۱۰۰٪</strong>
     تمرین عملی
    </div>

   </div>
  </section>

  <section>

   <div class="section-title">
    <h2>💻 مسیرهای آموزشی</h2>
    <p>مسیر تخصصی خودت را انتخاب کن.</p>
   </div>

   <div class="grid" id="homeCourses">

    <article class="card">
     <div class="card-icon">🐍</div>
     <h3>Python</h3>
     <p>آموزش پایتون از مقدماتی تا پیشرفته.</p>
    </article>

    <article class="card">
     <div class="card-icon">⚡</div>
     <h3>JavaScript</h3>
     <p>ساخت وب‌سایت‌های تعاملی و حرفه‌ای.</p>
    </article>

    <article class="card">
     <div class="card-icon">⚛️</div>
     <h3>React</h3>
     <p>طراحی رابط کاربری مدرن.</p>
    </article>

    <article class="card">
     <div class="card-icon">🗄️</div>
     <h3>Backend</h3>
     <p>ساخت سرور و API و پایگاه داده.</p>
    </article>

    <article class="card">
     <div class="card-icon">🤖</div>
     <h3>ربات تلگرام</h3>
     <p>ساخت ربات‌های هوشمند با Python.</p>
    </article>

    <article class="card">
     <div class="card-icon">⌨️</div>
     <h3>اتوماسیون</h3>
     <p>ساخت ابزارهای هوشمند و کاربردی.</p>
    </article>

   </div>

  </section>

  <section>

   <div class="section-title">
    <h2>✨ چرا آکادمی اراد؟</h2>
   </div>

   <div class="grid">

    <article class="card">
     <div class="card-icon">📚</div>
     <h3>آموزش فصل‌بندی‌شده</h3>
     <p>درس‌های منظم از سطح پایه تا پیشرفته.</p>
    </article>

    <article class="card">
     <div class="card-icon">🧪</div>
     <h3>تمرین و آزمون</h3>
     <p>ارزیابی دانش و انجام پروژه‌های عملی.</p>
    </article>

    <article class="card">
     <div class="card-icon">🏆</div>
     <h3>گواهی پایان دوره</h3>
     <p>دریافت گواهی آزمایشی پس از تکمیل دوره.</p>
    </article>

   </div>

  </section>

 </div>

</section>

<section id="courses" class="page container">
 <div class="section-title">
  <h2>📚 مرکز آموزش آکادمی</h2>
  <p>دوره مورد نظرت را انتخاب کن.</p>
 </div>
 <input class="search" placeholder="جستجوی Python، JavaScript، React...">
 <div class="grid" id="courseList"></div>
</section>

<section id="projects" class="page container">
 <div class="section-title">
  <h2>🚀 پروژه‌های عملی</h2>
  <p>دانسته‌هایت را به پروژه واقعی تبدیل کن.</p>
 </div>
 <div class="grid">
  <article class="card">
   <div class="card-icon">🤖</div>
   <h3>ربات تلگرام</h3>
   <p>ساخت ربات آموزشی با Python.</p>
  </article>
  <article class="card">
   <div class="card-icon">🌐</div>
   <h3>وب‌سایت شخصی</h3>
   <p>ساخت سایت واکنش‌گرا.</p>
  </article>
  <article class="card">
   <div class="card-icon">📊</div>
   <h3>مدیریت اطلاعات</h3>
   <p>طراحی سیستم مدیریت داده.</p>
  </article>
 </div>
</section>

<section id="sources" class="page container">
 <div class="section-title">
  <h2>📦 دانلود سورس‌کد</h2>
  <p>فایل‌های تمرینی و پروژه‌های رایگان.</p>
 </div>
 <div class="grid" id="sourceList"></div>
</section>

<section id="account" class="page container">
 <div class="panel">
  <h2>👤 حساب کاربری دانش‌آموز</h2>
  <p class="notice">
   سیستم حساب کاربری در بخش‌های بعدی تکمیل می‌شود.
  </p>
 </div>
</section>

<section id="dashboard" class="page container">
 <div class="panel">
  <h2>داشبورد دانش‌آموز</h2>
  <p>بخش پروفایل و پیشرفت در بخش بعدی اضافه می‌شود.</p>
 </div>
</section>

</main>

<footer>
 <h3 class="gradient">ARAD KALANTER ACADEMY</h3>
 <p>کدنویسی و هوش مصنوعی</p>
 <p>آموزش، تمرین، تجربه و پیشرفت</p>
 <small>© 2026 ARAD ACADEMY</small>
</footer>

<script>
function showPage(id,button){
 document.querySelectorAll('.page').forEach(page=>{
  page.classList.remove('active');
 });

 const target=document.getElementById(id);

 if(target){
  target.classList.add('active');
 }

 document.querySelectorAll('.nav-links button').forEach(btn=>{
  btn.classList.remove('active');
 });

 if(button){
  button.classList.add('active');
 }

 document.getElementById('navLinks').classList.remove('open');

 window.scrollTo({
  top:0,
  behavior:'smooth'
 });
}

function toggleMenu(){
 document.getElementById('navLinks').classList.toggle('open');
}
</script>

</body>
</html>

<!-- ==============================
     ARAD ACADEMY - PART 2
     COURSE MANAGEMENT SYSTEM
================================ -->

<section id="academy-courses" class="academy-section">
  <div class="academy-heading">
    <span class="academy-tag">ARAD ACADEMY</span>
    <h1>مرکز آموزش کدنویسی و هوش مصنوعی</h1>
    <p>از صفر شروع کن و به یک برنامه‌نویس حرفه‌ای تبدیل شو.</p>
  </div>

  <div class="academy-search">
    <input
      type="search"
      id="academySearch"
      placeholder="جستجوی Python، JavaScript، React..."
      oninput="academyRenderCourses()"
    >
  </div>

  <div id="academyCourseGrid" class="academy-grid"></div>
  <div id="academyCourseDetails"></div>
</section>

<style>
.academy-section {
  direction: rtl;
  padding: 45px 5%;
  color: #fff;
  font-family: Tahoma, sans-serif;
}

.academy-heading {
  text-align: center;
  margin-bottom: 35px;
}

.academy-heading h1 {
  font-size: clamp(25px, 4vw, 42px);
  color: #67e8f9;
  text-shadow: 0 0 20px #06b6d4;
}

.academy-tag {
  color: #a78bfa;
  letter-spacing: 3px;
}

.academy-search input {
  width: 100%;
  padding: 16px;
  border-radius: 15px;
  background: #101b32;
  border: 1px solid #38bdf8;
  color: white;
  margin-bottom: 25px;
  box-sizing: border-box;
}

.academy-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit,minmax(230px,1fr));
  gap: 20px;
}

.academy-card {
  background: linear-gradient(145deg,#15243c,#091426);
  border: 1px solid #334b70;
  padding: 22px;
  border-radius: 20px;
  box-shadow: 0 0 18px #0ea5e922;
  transition: .3s;
}

.academy-card:hover {
  transform: translateY(-7px);
  border-color: #22d3ee;
  box-shadow: 0 0 25px #06b6d455;
}

.academy-card h3 {
  color: #67e8f9;
}

.academy-btn {
  background: linear-gradient(90deg,#0891b2,#6366f1);
  border: 0;
  color: white;
  padding: 12px 20px;
  border-radius: 10px;
  cursor: pointer;
  margin-top: 12px;
}

.academy-chapter {
  background: #101b32;
  border: 1px solid #334b70;
  border-radius: 15px;
  padding: 18px;
  margin: 15px 0;
}

.academy-lesson {
  background: #172943;
  border-radius: 10px;
  padding: 14px;
  margin: 10px 0;
}

.academy-lesson pre {
  direction: ltr;
  text-align: left;
  overflow-x: auto;
  background: #050b16;
  padding: 15px;
  border-radius: 10px;
  color: #86efac;
}

.academy-details {
  margin-top: 30px;
}

.academy-details p {
  line-height: 2;
}

@media(max-width:600px) {
  .academy-section {
    padding: 25px 4%;
  }
}
</style>

<script>
const ARAD_COURSES = [
{
 id:"python",
 icon:"🐍",
 name:"Python جامع",
 level:"مقدماتی تا پیشرفته",
 description:"آموزش کامل پایتون از صفر تا ساخت پروژه و هوش مصنوعی.",
 lessons:[
 ["معرفی Python","Python زبانی ساده و قدرتمند برای وب، هوش مصنوعی و اتوماسیون است.","print('Hello ARAD')"],
 ["نصب Python","نصب Python و اجرای اولین برنامه.","python --version"],
 ["متغیرها","ذخیره اطلاعات در متغیرها.","name = 'Arad'\nage = 20\nprint(name, age)"],
 ["انواع داده","آشنایی با int و float و str و bool.","x = 20\nprice = 19.5\nname = 'Arad'\nactive = True"],
 ["ورودی و خروجی","دریافت اطلاعات از کاربر.","name = input('Name: ')\nprint('Hello', name)"],
 ["عملگرهای ریاضی","محاسبات ریاضی در Python.","print(10 + 5)\nprint(10 * 5)"],
 ["شرط if","تصمیم‌گیری در برنامه.","age = 18\nif age >= 18:\n print('Adult')"],
 ["if و else","اجرای حالت‌های مختلف.","score = 17\nif score >= 18:\n print('Excellent')\nelse:\n print('Practice')"],
 ["حلقه for","تکرار دستورات.","for i in range(5):\n print(i)"],
 ["حلقه while","تکرار تا برقرار بودن شرط.","x = 1\nwhile x <= 5:\n print(x)\n x += 1"],
 ["لیست‌ها","نگهداری چند مقدار.","names = ['Ali','Sara','Arad']\nprint(names)"],
 ["متدهای لیست","افزودن و حذف اطلاعات.","items = [1,2,3]\nitems.append(4)\nprint(items)"],
 ["دیکشنری","ذخیره اطلاعات کلید و مقدار.","user = {'name':'Arad','age':20}\nprint(user['name'])"],
 ["مجموعه‌ها","نگهداری داده‌های یکتا.","numbers = {1,2,2,3}\nprint(numbers)"],
 ["توابع","ساخت توابع قابل استفاده مجدد.","def greet(name):\n return 'Hello '+name\nprint(greet('Arad'))"],
 ["پارامترها","ارسال ورودی به تابع.","def add(a,b):\n return a+b\nprint(add(5,3))"],
 ["Lambda","توابع کوتاه.","double = lambda x: x*2\nprint(double(5))"],
 ["ماژول‌ها","استفاده از کتابخانه‌ها.","import math\nprint(math.sqrt(25))"],
 ["مدیریت فایل","خواندن و نوشتن فایل.","with open('test.txt','w') as f:\n f.write('ARAD')"],
 ["مدیریت خطا","کنترل خطاهای برنامه.","try:\n print(10/0)\nexcept ZeroDivisionError:\n print('Error')"],
 ["کلاس و شیء","شروع برنامه‌نویسی شی‌گرا.","class Student:\n def __init__(self,name):\n  self.name=name"],
 ["سازنده کلاس","استفاده از __init__.","class Car:\n def __init__(self,brand):\n  self.brand=brand"],
 ["وراثت","استفاده مجدد از کلاس‌ها.","class Animal:\n def sound(self):\n  return 'Sound'\nclass Dog(Animal):\n pass"],
 ["پکیج‌ها","ساختاردهی پروژه.","import datetime\nprint(datetime.date.today())"],
 ["JSON","ذخیره اطلاعات ساختاریافته.","import json\ndata={'name':'Arad'}\nprint(json.dumps(data))"],
 ["API","دریافت اطلاعات از سرویس‌ها.","import urllib.request\n# دریافت اطلاعات از یک API عمومی"],
 ["پایگاه داده","آشنایی با SQLite.","import sqlite3\nconnection=sqlite3.connect('academy.db')"],
 ["برنامه‌نویسی شی‌گرا","طراحی کلاس‌های کاربردی.","class Book:\n def __init__(self,title):\n  self.title=title"],
 ["اتوماسیون","خودکارسازی کارها.","from pathlib import Path\nprint(list(Path('.').iterdir()))"],
 ["پروژه مدیریت دانش‌آموز","ساخت برنامه مدیریت دانش‌آموز.","students=[]\nstudents.append({'name':'Arad','grade':19})\nprint(students)"],
 ["پروژه نهایی Python","ترکیب مهارت‌ها در یک پروژه واقعی.","def average(grades):\n return sum(grades)/len(grades)\nprint(average([18,20,19]))"]
 ]
},
{
 id:"javascript",
 icon:"⚡",
 name:"JavaScript حرفه‌ای",
 level:"مقدماتی تا پیشرفته",
 description:"ساخت وب‌سایت‌های تعاملی و برنامه‌های مدرن.",
 lessons:[
 ["معرفی JavaScript","JavaScript رفتار صفحات وب را کنترل می‌کند.","console.log('ARAD')"],
 ["نصب محیط توسعه","آشنایی با VS Code و مرورگر.","console.log('Start')"],
 ["متغیرها","استفاده از let و const.","const name='Arad';\nlet age=20;"],
 ["انواع داده","string و number و boolean و object.","console.log(typeof 'Hello')"],
 ["عملگرها","محاسبات و مقایسه.","console.log(10+5)"],
 ["شرط‌ها","استفاده از if و else.","if(10>5){console.log('Yes')}"],
 ["حلقه for","تکرار دستورات.","for(let i=0;i<5;i++) console.log(i)"],
 ["حلقه while","تکرار شرطی.","let i=0;\nwhile(i<5){console.log(i);i++}"],
 ["توابع","تعریف تابع.","function greet(){return 'Hello'}"],
 ["Arrow Functions","توابع پیکانی.","const add=(a,b)=>a+b;"],
 ["آرایه‌ها","ذخیره مجموعه داده.","const names=['Ali','Sara']"],
 ["متدهای آرایه","map و filter و reduce.","const nums=[1,2,3];\nconsole.log(nums.map(x=>x*2))"],
 ["Object","ساخت اشیا.","const user={name:'Arad',age:20}"],
 ["Destructuring","استخراج داده از اشیا.","const {name}={name:'Arad'}"],
 ["DOM","کنترل عناصر HTML.","document.querySelector('h1')"],
 ["رویدادها","واکنش به کلیک.","document.querySelector('button')?.addEventListener('click',()=>alert('Hello'))"],
 ["فرم‌ها","دریافت اطلاعات کاربر.","const formData=new FormData()"],
 ["اعتبارسنجی","بررسی ورودی‌ها.","const email='test@example.com';\nconsole.log(email.includes('@'))"],
 ["LocalStorage","ذخیره اطلاعات مرورگر.","localStorage.setItem('name','Arad')"],
 ["JSON","تبادل اطلاعات.","JSON.stringify({name:'Arad'})"],
 ["Promise","مدیریت عملیات ناهم‌زمان.","Promise.resolve('Done').then(console.log)"],
 ["Async Await","کدنویسی ناهم‌زمان.","async function run(){return await Promise.resolve(10)}"],
 ["Fetch","ارتباط با API.","fetch('/api/courses').then(r=>r.json())"],
 ["مدیریت خطا","استفاده از try و catch.","try { JSON.parse('{') } catch(e) { console.log('Invalid') }"],
 ["ماژول‌ها","import و export.","export const academy='ARAD'"],
 ["کلاس‌ها","برنامه‌نویسی شی‌گرا.","class Student { constructor(name){this.name=name} }"],
 ["وراثت","گسترش کلاس‌ها.","class Admin extends User {}"],
 ["Node.js","اجرای JavaScript خارج مرورگر.","console.log('Node.js')"],
 ["کار با API","ارتباط با سرویس‌ها.","const data={title:'Course'};\nconsole.log(data)"],
 ["پروژه Todo","ساخت فهرست وظایف.","const tasks=[];\ntasks.push('Learn JS')"]
 ]
},
{
 id:"react",
 icon:"⚛️",
 name:"React",
 level:"پیشرفته",
 description:"ساخت رابط‌های کاربری مدرن و کامپوننتی.",
 lessons:[
 ["معرفی React","React کتابخانه ساخت رابط کاربری است.","function App(){return <h1>ARAD</h1>}"],
 ["JSX","نوشتن ساختار رابط در JavaScript.","const element=<h1>Hello</h1>"],
 ["Components","ساخت کامپوننت.","function Welcome(){return <h1>Welcome</h1>}"],
 ["Props","ارسال اطلاعات بین کامپوننت‌ها.","function User({name}){return <p>{name}</p>}"],
 ["useState","مدیریت وضعیت.","const [count,setCount]=useState(0)"],
 ["رویدادها","مدیریت کلیک.","<button onClick={()=>alert('Hi')}>Click</button>"],
 ["شرط در JSX","نمایش شرطی.","{isLoggedIn ? 'Welcome' : 'Login'}"],
 ["لیست‌ها","نمایش آرایه.","items.map(item=><p key={item.id}>{item.name}</p>)"],
 ["useEffect","همگام‌سازی با API و منابع بیرونی.","useEffect(()=>{},[])"],
 ["فرم‌ها","ساخت فرم کنترل‌شده.","<input value={name} onChange={e=>setName(e.target.value)} />"],
 ["Context","اشتراک وضعیت.","const AcademyContext=createContext()"],
 ["useRef","نگهداری ارجاع.","const inputRef=useRef(null)"],
 ["Custom Hooks","ساخت Hook اختصاصی.","function useAcademy(){return 'ARAD'}"],
 ["React Router","مسیریابی صفحات.","// Configure Routes"],
 ["API","دریافت اطلاعات.","// Fetch data in an effect"],
 ["Loading","نمایش وضعیت بارگذاری.","if(loading)return <p>Loading</p>"],
 ["Error State","نمایش خطا.","if(error)return <p>Error</p>"],
 ["CSS در React","طراحی کامپوننت.","// Import component styles"],
 ["ساخت کارت دوره","کامپوننت کارت.","function Card(){return <article>Course</article>}"],
 ["پروژه Todo","مدیریت وظایف.","// Build a Todo component"],
 ]
},
{
 id:"backend",
 icon:"🗄️",
 name:"Backend و API",
 level:"پیشرفته",
 description:"سرور، HTTP، پایگاه داده و طراحی API.",
 lessons:[
 ["معرفی Backend","منطق سمت سرور و ارتباط با پایگاه داده.","// Server-side application"],
 ["کلاینت و سرور","چرخه درخواست و پاسخ.","Client -> Server -> Response"],
 ["HTTP","شناخت پروتکل HTTP.","GET /api/courses"],
 ["متدهای HTTP","GET و POST و PUT و DELETE.","POST /api/users"],
 ["REST API","طراحی منابع API.","GET /api/students"],
 ["JSON","ساختار داده‌های API.","{\"name\":\"Arad\"}"],
 ["Node.js","اجرای JavaScript در سرور.","console.log('Server')"],
 ["Express","ساخت سرور.","// Express application"],
 ["Routing","تعریف مسیرها.","// app.get('/courses', handler)"],
 ["Middleware","پردازش درخواست.","// app.use(middleware)"],
 ["SQL","پایگاه داده رابطه‌ای.","SELECT * FROM students;"],
 ["جداول","ساختار جدول‌ها.","CREATE TABLE courses(id INTEGER PRIMARY KEY);"],
 ["کلید خارجی","ارتباط جدول‌ها.","REFERENCES courses(id)"],
 ["CRUD","ایجاد و خواندن و ویرایش و حذف.","// Create Read Update Delete"],
 ["Authentication","احراز هویت کاربران.","// Secure authentication"],
 ["Password Hashing","ذخیره امن رمزها.","// Use a password hashing library"],
 ["Authorization","کنترل سطح دسترسی.","// Verify permissions on server"],
 ["Validation","اعتبارسنجی اطلاعات.","// Validate request data"],
 ["Error Handling","مدیریت خطا.","// Handle server errors"],
 ["Environment Variables","مدیریت تنظیمات محرمانه.","// Read secrets from environment"],
 ]
},
{
 id:"telegram",
 icon:"🤖",
 name:"ربات تلگرام",
 level:"متوسط تا پیشرفته",
 description:"ساخت ربات آموزشی با Python و Telegram Bot API.",
 lessons:[
 ["معرفی ربات","آشنایی با Bot API.","# Telegram Bot API"],
 ["BotFather","ایجاد ربات آزمایشی.","# Create a bot using BotFather"],
 ["توکن امن","نگهداری توکن در متغیر محیطی.","import os\nTOKEN=os.getenv('BOT_TOKEN')"],
 ["ساختار ربات","آشنایی با handlerها.","def start(): print('Welcome')"],
 ["فرمان Start","پیام خوش‌آمدگویی.","def start_message(): return 'Welcome to ARAD'"],
 ["فرمان Help","راهنمای ربات.","def help_message(): return 'Help'"],
 ["دریافت پیام","پردازش ورودی کاربر.","def process_message(text): return text"],
 ["دکمه‌ها","طراحی منوی ربات.","menu=['Courses','Profile','Help']"],
 ["Inline Keyboard","مفهوم دکمه‌های درون پیام.","# Inline keyboard concept"],
 ["پایگاه داده","ذخیره کاربران.","# SQLite database"],
 ["پروفایل","نمایش اطلاعات کاربر.","# User profile feature"],
 ["ارسال پیام","ارسال پاسخ مناسب.","# Send a message via Bot API"],
 ["دوره‌ها","نمایش فهرست آموزش‌ها.","courses=['Python','JavaScript']"],
 ["آزمون","ساخت آزمون ساده.","questions=['Python','JavaScript']"],
 ["مدیریت خطا","ثبت و مدیریت خطاها.","import logging"],
 ["امنیت","محافظت از اطلاعات محرمانه.","# Keep tokens private"],
 ["استقرار","آماده‌سازی سرویس.","# Deploy using a secure host"],
 ]
},
{
 id:"automation",
 icon:"⚙️",
 name:"اسکریپت‌نویسی و اتوماسیون",
 level:"متوسط",
 description:"ساخت ابزارهای کاربردی و خودکارسازی کارها.",
 lessons:[
 ["معرفی اسکریپت","برنامه‌های کوچک برای کارهای تکراری.","print('Automation started')"],
 ["تاریخ و ساعت","استفاده از datetime.","from datetime import datetime\nprint(datetime.now())"],
 ["فایل‌ها","مدیریت فایل.","from pathlib import Path"],
 ["پوشه‌ها","ساخت پوشه.","Path('reports').mkdir(exist_ok=True)"],
 ["CSV","پردازش داده جدولی.","import csv"],
 ["JSON","ذخیره اطلاعات.","import json"],
 ["اتوماسیون گزارش","ساخت گزارش روزانه.","def report(): print('Daily report')"],
 ["پروژه فایل‌ها","مرتب‌سازی فایل‌ها.","# Build a safe file organizer"],
 ["پروژه CSV","تحلیل داده.","# Analyze student grades"],
 ["پروژه نهایی","ساخت ابزار اتوماسیون.","# Build a useful automation tool"]
 ]
}
];

function academyRenderCourses(){
 const query=(document.getElementById('academySearch')?.value||'').toLowerCase();
 const grid=document.getElementById('academyCourseGrid');
 if(!grid)return;
 grid.innerHTML=ARAD_COURSES.filter(c=>(c.name+' '+c.description).toLowerCase().includes(query)).map(c=>`
  <article class="academy-card">
   <div style="font-size:42px">${c.icon}</div>
   <h3>${c.name}</h3>
   <p>${c.description}</p>
   <p>سطح: ${c.level}</p>
   <p>تعداد درس: ${c.lessons.length}</p>
   <button class="academy-btn" onclick="academyOpenCourse('${c.id}')">مشاهده دوره ←</button>
  </article>
 `).join('') || '<p>دوره‌ای یافت نشد.</p>';
}

function academyOpenCourse(id){
 const course=ARAD_COURSES.find(c=>c.id===id);
 if(!course)return;
 const target=document.getElementById('academyCourseDetails');
 target.innerHTML=`
  <div class="academy-details">
   <h2>${course.icon} ${course.name}</h2>
   <p>${course.description}</p>
   <div class="academy-chapter">
    <h3>فصل اول: آموزش و تمرین</h3>
    ${course.lessons.map((lesson,index)=>`
     <div class="academy-lesson">
      <h4>درس ${index+1}: ${lesson[0]}</h4>
      <p>${lesson[1]}</p>
      <pre><code>${academyEscape(lesson[2])}</code></pre>
      <p>تمرین: یک نمونه مستقل از موضوع این درس بنویس و نتیجه را بررسی کن.</p>
      <a target="_blank" rel="noopener" href="https://www.youtube.com/results?search_query=${encodeURIComponent(course.name+' '+lesson[0]+' tutorial')}">🎬 جستجوی ویدیوی آموزشی</a>
     </div>
    `).join('')}
   </div>
  </div>
 `;
 target.scrollIntoView({behavior:'smooth'});
}

function academyEscape(value){
 return String(value).replace(/[&<>"']/g,c=>({
  '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
 })[c]);
}

academyRenderCourses();
</script>
<!-- END ARAD ACADEMY PART 2 -->

<!-- ===================================
 ARAD ACADEMY - PART 3
 STUDENT ACCOUNT AND PROGRESS SYSTEM
=================================== -->

<section id="arad-student" class="arad-student-section">

 <div class="arad-account-header">
  <span>🎓 ARAD ACADEMY</span>
  <h1>پنل اختصاصی دانش‌آموزان</h1>
  <p>پیشرفتت را دنبال کن و به موفقیت نزدیک‌تر شو.</p>
 </div>

 <div id="aradAuthPanel" class="arad-account-card">
  <h2>👤 حساب کاربری</h2>

  <div class="arad-auth-tabs">
   <button onclick="aradShowAuth('register')">ثبت‌نام</button>
   <button onclick="aradShowAuth('login')">ورود</button>
  </div>

  <div id="aradRegisterForm">
   <input id="aradRegName" placeholder="نام و نام خانوادگی">
   <input id="aradRegEmail" type="email" placeholder="ایمیل">
   <input id="aradRegPass" type="password" placeholder="رمز عبور">
   <button class="arad-main-btn" onclick="aradRegister()">ثبت‌نام در آکادمی</button>
  </div>

  <div id="aradLoginForm" style="display:none">
   <input id="aradLoginEmail" type="email" placeholder="ایمیل">
   <input id="aradLoginPass" type="password" placeholder="رمز عبور">
   <button class="arad-main-btn" onclick="aradLogin()">ورود به حساب</button>
  </div>

  <p id="aradAuthMessage"></p>
  <small>این نسخه آزمایشی است و اطلاعات در مرورگر ذخیره می‌شود.</small>
 </div>

 <div id="aradStudentDashboard" style="display:none">

  <div class="arad-account-card">
   <div class="arad-profile-top">
    <div class="arad-avatar">👨‍💻</div>
    <div>
     <h2 id="aradStudentName">دانش‌آموز</h2>
     <p id="aradStudentEmail"></p>
     <span class="arad-online">● حساب فعال</span>
    </div>
   </div>

   <div class="arad-stats">
    <div><strong id="aradTotalCourses">۶</strong><span>دوره‌ها</span></div>
    <div><strong id="aradDoneLessons">۰</strong><span>درس تکمیل‌شده</span></div>
    <div><strong id="aradAverageScore">۰</strong><span>میانگین نمرات</span></div>
   </div>
  </div>

  <div class="arad-account-card">
   <h2>📈 پیشرفت آموزشی</h2>
   <div id="aradProgressList"></div>
  </div>

  <div class="arad-account-card">
   <h2>📝 آزمون‌های من</h2>
   <div id="aradExamResults"></div>
  </div>

  <div class="arad-account-card">
   <h2>🏆 گواهی‌های من</h2>
   <div id="aradCertificates"></div>
  </div>

  <div class="arad-account-card">
   <h2>📂 تمرین‌های ذخیره‌شده</h2>
   <div id="aradSavedExercises"></div>
  </div>

  <button class="arad-main-btn" onclick="aradLogout()">خروج از حساب</button>
 </div>

</section>

<style>
.arad-student-section {
 direction:rtl;
 padding:45px 5%;
 color:#fff;
 font-family:Tahoma,sans-serif;
}

.arad-account-header {
 text-align:center;
 margin-bottom:35px;
}

.arad-account-header span {
 color:#a78bfa;
 letter-spacing:3px;
}

.arad-account-header h1 {
 color:#67e8f9;
 font-size:clamp(25px,4vw,40px);
 text-shadow:0 0 20px #06b6d4;
}

.arad-account-card {
 background:linear-gradient(145deg,#172943,#091426);
 border:1px solid #334b70;
 border-radius:20px;
 padding:25px;
 margin:22px 0;
 box-shadow:0 0 20px #06b6d415;
}

.arad-account-card h2 {
 color:#67e8f9;
}

.arad-account-card input {
 display:block;
 width:100%;
 box-sizing:border-box;
 margin:12px 0;
 padding:15px;
 border-radius:10px;
 border:1px solid #365579;
 background:#071326;
 color:white;
 outline:none;
}

.arad-account-card input:focus {
 border-color:#22d3ee;
 box-shadow:0 0 12px #22d3ee55;
}

.arad-auth-tabs {
 display:flex;
 gap:10px;
 margin:20px 0;
}

.arad-auth-tabs button {
 flex:1;
 padding:13px;
 border-radius:10px;
 border:1px solid #38bdf8;
 background:#132b48;
 color:white;
 cursor:pointer;
}

.arad-main-btn {
 background:linear-gradient(90deg,#0891b2,#6366f1);
 color:white;
 padding:14px 22px;
 border:0;
 border-radius:12px;
 cursor:pointer;
 margin:8px 0;
 font-weight:bold;
}

.arad-main-btn:hover {
 box-shadow:0 0 20px #22d3ee77;
}

.arad-profile-top {
 display:flex;
 align-items:center;
 gap:20px;
}

.arad-avatar {
 width:75px;
 height:75px;
 border-radius:50%;
 background:#153858;
 display:grid;
 place-items:center;
 font-size:35px;
}

.arad-online {
 color:#4ade80;
}

.arad-stats {
 display:grid;
 grid-template-columns:repeat(3,1fr);
 gap:12px;
 margin-top:25px;
}

.arad-stats div {
 text-align:center;
 padding:18px 8px;
 border-radius:12px;
 background:#0a1a30;
}

.arad-stats strong {
 display:block;
 font-size:26px;
 color:#67e8f9;
 margin-bottom:8px;
}

.arad-stats span {
 font-size:12px;
}

.arad-progress-item {
 background:#0a1a30;
 padding:15px;
 border-radius:12px;
 margin:12px 0;
}

.arad-progress-track {
 height:10px;
 background:#263c57;
 border-radius:20px;
 overflow:hidden;
 margin-top:10px;
}

.arad-progress-track span {
 display:block;
 height:100%;
 background:linear-gradient(90deg,#06b6d4,#8b5cf6);
}

.arad-result-item {
 padding:15px;
 margin:10px 0;
 border-radius:12px;
 background:#0a1a30;
 border:1px solid #253d59;
}

.arad-certificate {
 border:2px dashed #38bdf8;
 border-radius:15px;
 padding:20px;
 margin:12px 0;
 text-align:center;
}

#aradAuthMessage {
 color:#fbbf24;
 line-height:2;
}

@media(max-width:600px) {
 .arad-student-section {padding:25px 4%}
 .arad-stats {grid-template-columns:1fr}
 .arad-account-card {padding:18px}
}
</style>

<script>
const ARAD_STUDENT_KEY = "ARAD_STUDENT_SYSTEM_V1";

let aradStudentDB;

try {
 aradStudentDB = JSON.parse(
  localStorage.getItem(ARAD_STUDENT_KEY)
 ) || {};
} catch(e) {
 aradStudentDB = {};
}

aradStudentDB.users = aradStudentDB.users || [];
aradStudentDB.current = aradStudentDB.current || null;
aradStudentDB.progress = aradStudentDB.progress || {};
aradStudentDB.exams = aradStudentDB.exams || {};
aradStudentDB.exercises = aradStudentDB.exercises || {};
aradStudentDB.certificates = aradStudentDB.certificates || {};

function aradSaveDB() {
 localStorage.setItem(
  ARAD_STUDENT_KEY,
  JSON.stringify(aradStudentDB)
 );
}

function aradMessage(message) {
 document.getElementById("aradAuthMessage").textContent = message;
}

function aradShowAuth(type) {
 document.getElementById("aradRegisterForm").style.display =
  type === "register" ? "block" : "none";

 document.getElementById("aradLoginForm").style.display =
  type === "login" ? "block" : "none";

 aradMessage("");
}

function aradRegister() {
 const name = document.getElementById("aradRegName").value.trim();
 const email = document.getElementById("aradRegEmail").value.trim().toLowerCase();
 const password = document.getElementById("aradRegPass").value;

 if(!name || !email || password.length < 8) {
  aradMessage("نام، ایمیل و رمز حداقل ۸ کاراکتری لازم است.");
  return;
 }

 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
  aradMessage("ایمیل معتبر وارد کن.");
  return;
 }

 if(aradStudentDB.users.some(u => u.email === email)) {
  aradMessage("این ایمیل قبلاً ثبت شده است.");
  return;
 }

 const user = {
  id: "student_" + Date.now(),
  name,
  email,
  password,
  createdAt: new Date().toISOString()
 };

 aradStudentDB.users.push(user);
 aradStudentDB.current = user.id;

 aradSaveDB();
 aradRenderDashboard();
}

function aradLogin() {
 const email = document.getElementById("aradLoginEmail").value.trim().toLowerCase();
 const password = document.getElementById("aradLoginPass").value;

 const user = aradStudentDB.users.find(
  u => u.email === email && u.password === password
 );

 if(!user) {
  aradMessage("ایمیل یا رمز عبور اشتباه است.");
  return;
 }

 aradStudentDB.current = user.id;
 aradSaveDB();
 aradRenderDashboard();
}

function aradCurrentUser() {
 return aradStudentDB.users.find(
  u => u.id === aradStudentDB.current
 );
}

function aradLogout() {
 aradStudentDB.current = null;
 aradSaveDB();

 document.getElementById("aradStudentDashboard").style.display = "none";
 document.getElementById("aradAuthPanel").style.display = "block";

 aradShowAuth("login");
 aradMessage("با موفقیت خارج شدی.");
}

function aradGetCourses() {
 if(typeof ARAD_COURSES !== "undefined") {
  return ARAD_COURSES;
 }
 return [];
}

function aradRenderDashboard() {
 const user = aradCurrentUser();

 if(!user) {
  document.getElementById("aradStudentDashboard").style.display = "none";
  document.getElementById("aradAuthPanel").style.display = "block";
  return;
 }

 document.getElementById("aradAuthPanel").style.display = "none";
 document.getElementById("aradStudentDashboard").style.display = "block";

 document.getElementById("aradStudentName").textContent = user.name;
 document.getElementById("aradStudentEmail").textContent = user.email;

 const courses = aradGetCourses();
 let totalDone = 0;
 let totalScore = 0;
 let examCount = 0;

 const progressHTML = courses.map(course => {
  const done = aradStudentDB.progress[course.id] || [];
  const total = course.lessons.length;
  totalDone += done.length;

  const percent = total
   ? Math.round(done.length / total * 100)
   : 0;

  return `
   <div class="arad-progress-item">
    <strong>${aradEscape(course.name)}</strong>
    <p>${done.length} از ${total} درس - ${percent}٪</p>
    <div class="arad-progress-track">
     <span style="width:${percent}%"></span>
    </div>
   </div>
  `;
 }).join("");

 document.getElementById("aradProgressList").innerHTML =
  progressHTML || "هنوز دوره‌ای وجود ندارد.";

 const examHTML = [];

 Object.entries(aradStudentDB.exams).forEach(([courseId,results]) => {
  results.filter(r => r.userId === user.id).forEach(result => {
   totalScore += result.percent;
   examCount++;

   examHTML.push(`
    <div class="arad-result-item">
     <strong>${aradEscape(result.courseName)}</strong>
     <p>نمره: ${result.score} از ${result.total}</p>
     <p>درصد: ${result.percent}٪</p>
     <small>${new Date(result.date).toLocaleDateString("fa-IR")}</small>
    </div>
   `);
  });
 });

 document.getElementById("aradExamResults").innerHTML =
  examHTML.join("") || "هنوز در آزمونی شرکت نکرده‌ای.";

 document.getElementById("aradTotalCourses").textContent = courses.length;
 document.getElementById("aradDoneLessons").textContent = totalDone;
 document.getElementById("aradAverageScore").textContent =
  examCount ? Math.round(totalScore / examCount) : 0;

 const certificateHTML = courses.map(course => {
  const done = aradStudentDB.progress[course.id] || [];
  const completed = course.lessons.length > 0 &&
   done.length >= course.lessons.length;

  if(!completed) return "";

  return `
   <div class="arad-certificate">
    <h3>🏆 ${aradEscape(course.name)}</h3>
    <p>تمام درس‌های این دوره تکمیل شده است.</p>
    <button class="arad-main-btn"
     onclick="aradPrintCertificate('${course.id}')">
     دریافت گواهی
    </button>
   </div>
  `;
 }).join("");

 document.getElementById("aradCertificates").innerHTML =
  certificateHTML || "برای دریافت گواهی، تمام درس‌های دوره را تکمیل کن.";

 const exercises = aradStudentDB.exercises[user.id] || {};

 document.getElementById("aradSavedExercises").innerHTML =
  Object.keys(exercises).length
   ? Object.entries(exercises).map(([key,value]) => `
     <div class="arad-result-item">
      <strong>${aradEscape(key)}</strong>
      <p>${aradEscape(value).slice(0,300)}</p>
     </div>
    `).join("")
   : "هنوز تمرینی ذخیره نشده است.";
}

function aradEscape(value) {
 return String(value).replace(/[&<>"']/g, c => ({
  "&":"&amp;",
  "<":"&lt;",
  ">":"&gt;",
  '"':"&quot;",
  "'":"&#39;"
 })[c]);
}

function aradCompleteLesson(courseId,lessonIndex) {
 const user = aradCurrentUser();

 if(!user) {
  alert("ابتدا وارد حساب دانش‌آموزی شو.");
  return;
 }

 aradStudentDB.progress[courseId] =
  aradStudentDB.progress[courseId] || [];

 if(!aradStudentDB.progress[courseId].includes(lessonIndex)) {
  aradStudentDB.progress[courseId].push(lessonIndex);
 }

 aradSaveDB();
 aradRenderDashboard();

 alert("پیشرفت درس ذخیره شد.");
}

function aradSaveExercise(courseId,lessonIndex,value) {
 const user = aradCurrentUser();

 if(!user) {
  alert("ابتدا وارد حساب شو.");
  return;
 }

 aradStudentDB.exercises[user.id] =
  aradStudentDB.exercises[user.id] || {};

 const key = courseId + "_lesson_" + lessonIndex;

 aradStudentDB.exercises[user.id][key] = value;

 aradSaveDB();
 alert("تمرین ذخیره شد.");
}

function aradRecordExam(courseId,courseName,score,total) {
 const user = aradCurrentUser();

 if(!user) {
  alert("برای ثبت نمره وارد حساب شو.");
  return;
 }

 aradStudentDB.exams[courseId] =
  aradStudentDB.exams[courseId] || [];

 const percent = total > 0
  ? Math.round(score / total * 100)
  : 0;

 aradStudentDB.exams[courseId].push({
  userId:user.id,
  courseName,
  score,
  total,
  percent,
  date:new Date().toISOString()
 });

 aradSaveDB();
 aradRenderDashboard();
}

function aradPrintCertificate(courseId) {
 const user = aradCurrentUser();
 const course = aradGetCourses().find(c => c.id === courseId);

 if(!user || !course) return;

 const done = aradStudentDB.progress[courseId] || [];

 if(done.length < course.lessons.length) {
  alert("هنوز همه درس‌ها تکمیل نشده‌اند.");
  return;
 }

 const win = window.open("", "_blank");

 if(!win) {
  alert("پنجره چاپ مسدود شده است.");
  return;
 }

 const html = `
 <!DOCTYPE html>
 <html lang="fa" dir="rtl">
 <head>
 <meta charset="UTF-8">
 <title>گواهی آکادمی اراد</title>
 <style>
 body {
  background:#071326;
  color:#fff;
  font-family:Tahoma;
  text-align:center;
  padding:35px;
 }
 .certificate {
  border:8px double #38bdf8;
  padding:55px 20px;
  margin:auto;
  max-width:800px;
 }
 h1 {color:#67e8f9}
 @media print {
  body {background:white;color:#111}
  h1 {color:#087eaa}
 }
 </style>
 </head>
 <body>
 <div class="certificate">
  <h1>ARAD KALANTER ACADEMY</h1>
  <h2>گواهی پایان دوره</h2>
  <p>این گواهی به نام</p>
  <h2>${aradEscape(user.name)}</h2>
  <p>برای تکمیل دوره آموزشی زیر صادر شده است:</p>
  <h2>${aradEscape(course.name)}</h2>
  <p>تاریخ صدور: ${new Date().toLocaleDateString("fa-IR")}</p>
  <p>ARAD ACADEMY</p>
  <button onclick="window.print()">چاپ گواهی</button>
 </div>
 </body>
 </html>
 `;

 win.document.open();
 win.document.write(html);
 win.document.close();
}

if(aradCurrentUser()) {
 aradRenderDashboard();
}
</script>

<!-- END PART 3 -->

<!-- ===============================
 ARAD ACADEMY - PART 4
 ADMIN PANEL
================================ -->

<section id="admin-panel" class="page container">
  <div class="admin-header">
    <span class="badge">ARAD ADMINISTRATION</span>
    <h1>پنل مدیریت اراد 👑</h1>
    <p>مدیریت دانش‌آموزان، دوره‌ها و نمرات</p>
  </div>

  <div id="admin-login" class="panel admin-box">
    <h2>🔐 ورود مدیر</h2>
    <input
      type="password"
      id="admin-password"
      class="field"
      placeholder="رمز اختصاصی مدیر"
    >
    <button class="btn" onclick="aradAdminLogin()">
      ورود به پنل مدیریت
    </button>
    <p id="admin-error" class="notice"></p>
  </div>

  <div id="admin-dashboard" hidden>
    <div class="grid">
      <div class="stat">
        <strong id="admin-users-count">0</strong>
        دانش‌آموز
      </div>
      <div class="stat">
        <strong id="admin-courses-count">0</strong>
        دوره
      </div>
      <div class="stat">
        <strong id="admin-lessons-count">0</strong>
        درس
      </div>
    </div>

    <div class="panel">
      <h2>👨‍🎓 مدیریت دانش‌آموزان</h2>
      <div id="admin-users"></div>
    </div>

    <div class="panel">
      <h2>📚 مدیریت دوره‌ها</h2>

      <input
        id="admin-course-name"
        class="field"
        placeholder="نام دوره جدید"
      >

      <input
        id="admin-course-description"
        class="field"
        placeholder="توضیحات دوره"
      >

      <input
        id="admin-course-price"
        class="field"
        type="number"
        min="50000"
        placeholder="قیمت دوره به تومان (حداقل ۵۰۰۰۰)"
      >

      <button class="btn" onclick="aradAddCourse()">
        افزودن دوره
      </button>

      <div id="admin-courses"></div>
    </div>

    <div class="panel">
      <h2>📝 ثبت نمره دانش‌آموز</h2>

      <select id="grade-user" class="field">
        <option value="">انتخاب دانش‌آموز</option>
      </select>

      <select id="grade-course" class="field">
        <option value="">انتخاب دوره</option>
      </select>

      <input
        id="grade-score"
        class="field"
        type="number"
        min="0"
        max="100"
        placeholder="نمره از ۱۰۰"
      >

      <textarea
        id="grade-description"
        class="field"
        placeholder="توضیحات و نظر مدیر"
      ></textarea>

      <button class="btn" onclick="aradGiveGrade()">
        ثبت نمره
      </button>
    </div>

    <div class="panel">
      <h2>📊 نمرات ثبت‌شده</h2>
      <div id="admin-grades"></div>
    </div>

    <button class="btn secondary" onclick="aradAdminLogout()">
      خروج از پنل مدیریت
    </button>
  </div>
</section>

<style>
.admin-header {
  text-align: center;
  padding: 35px 10px;
}

.admin-header h1 {
  font-size: clamp(25px, 5vw, 42px);
  color: #67e8f9;
  text-shadow: 0 0 20px #06b6d4;
}

.admin-box {
  max-width: 550px;
  margin: 30px auto;
}

#admin-dashboard .panel {
  margin: 25px 0;
}

#admin-dashboard .field {
  margin: 10px 0;
}

.admin-user,
.admin-course,
.admin-grade {
  padding: 15px;
  margin: 12px 0;
  border: 1px solid #38bdf8;
  border-radius: 14px;
  background: rgba(15, 35, 65, .65);
  overflow-wrap: anywhere;
}

.admin-danger {
  background: #991b1b;
  color: white;
  border: 0;
  padding: 9px 15px;
  border-radius: 9px;
  cursor: pointer;
}
</style>

<script>
/* ARAD ADMIN SYSTEM */

const ARAD_ADMIN_PASSWORD = "AradKalantar1392";

function aradAdminLogin() {
  const password =
    document.getElementById("admin-password").value;

  if (password !== ARAD_ADMIN_PASSWORD) {
    document.getElementById("admin-error").textContent =
      "رمز مدیر اشتباه است!";
    return;
  }

  sessionStorage.setItem("arad_admin_session", "active");

  document.getElementById("admin-login").hidden = true;
  document.getElementById("admin-dashboard").hidden = false;

  aradRenderAdmin();
}

function aradAdminLogout() {
  sessionStorage.removeItem("arad_admin_session");

  document.getElementById("admin-login").hidden = false;
  document.getElementById("admin-dashboard").hidden = true;

  document.getElementById("admin-password").value = "";
}

function aradCheckAdmin() {
  if (sessionStorage.getItem("arad_admin_session") === "active") {
    document.getElementById("admin-login").hidden = true;
    document.getElementById("admin-dashboard").hidden = false;
    aradRenderAdmin();
  }
}

function aradGetDB() {
  return JSON.parse(localStorage.getItem("arad_academy_v2") || "{}");
}

function aradSaveDB(data) {
  localStorage.setItem("arad_academy_v2", JSON.stringify(data));
}

function aradRenderAdmin() {
  if (sessionStorage.getItem("arad_admin_session") !== "active") {
    return;
  }

  const db = aradGetDB();

  db.users = db.users || [];
  db.courses = db.courses || [];
  db.grades = db.grades || [];

  document.getElementById("admin-users-count").textContent =
    db.users.length;

  document.getElementById("admin-courses-count").textContent =
    db.courses.length;

  document.getElementById("admin-lessons-count").textContent =
    db.courses.reduce((sum, course) =>
      sum + (course.chapters || []).reduce(
        (n, chapter) => n + (chapter.lessons || []).length, 0
      ), 0
    );

  document.getElementById("admin-users").innerHTML =
    db.users.map((user, index) => `
      <div class="admin-user">
        <strong>${escapeHTML(user.name)}</strong>
        <p>${escapeHTML(user.email)}</p>
        <button class="admin-danger"
          onclick="aradDeleteUser(${index})">
          حذف دانش‌آموز
        </button>
      </div>
    `).join("") || "هنوز دانش‌آموزی ثبت‌نام نکرده است.";

  document.getElementById("admin-courses").innerHTML =
    db.courses.map(course => `
      <div class="admin-course">
        <strong>${escapeHTML(course.name)}</strong>
        <p>${escapeHTML(course.description || "")}</p>
        <p>قیمت: ${Number(course.price || 0).toLocaleString("fa-IR")} تومان</p>
        <button class="admin-danger"
          onclick="aradDeleteCourse('${course.id}')">
          حذف دوره
        </button>
      </div>
    `).join("");

  document.getElementById("grade-user").innerHTML =
    '<option value="">انتخاب دانش‌آموز</option>' +
    db.users.map(user => `
      <option value="${escapeHTML(user.email)}">
        ${escapeHTML(user.name)}
      </option>
    `).join("");

  document.getElementById("grade-course").innerHTML =
    '<option value="">انتخاب دوره</option>' +
    db.courses.map(course => `
      <option value="${escapeHTML(course.id)}">
        ${escapeHTML(course.name)}
      </option>
    `).join("");

  document.getElementById("admin-grades").innerHTML =
    db.grades.map((grade, index) => `
      <div class="admin-grade">
        <strong>${escapeHTML(grade.student)}</strong>
        <p>دوره: ${escapeHTML(grade.course)}</p>
        <p>نمره: ${grade.score} از ۱۰۰</p>
        <p>${escapeHTML(grade.description)}</p>
        <button class="admin-danger"
          onclick="aradDeleteGrade(${index})">
          حذف نمره
        </button>
      </div>
    `).join("") || "هنوز نمره‌ای ثبت نشده است.";
}

function aradAddCourse() {
  if (!aradIsAdmin()) return;

  const db = aradGetDB();

  const name = document.getElementById("admin-course-name").value.trim();
  const description = document.getElementById("admin-course-description").value.trim();
  const price = Number(document.getElementById("admin-course-price").value);

  if (!name || !Number.isSafeInteger(price) || price < 50000) {
    alert("نام دوره و قیمت حداقل ۵۰ هزار تومان لازم است.");
    return;
  }

  db.courses = db.courses || [];

  db.courses.push({
    id: "arad_" + Date.now(),
    name,
    icon: "📘",
    level: "ویژه",
    description,
    price,
    image: "",
    chapters: [{
      title: "فصل اول",
      lessons: [{
        title: "درس اول",
        body: "محتوای این درس را مدیر تکمیل می‌کند.",
        code: "print('Welcome to ARAD')",
        task: "تمرین این درس را انجام بده."
      }]
    }],
    quiz: []
  });

  aradSaveDB(db);
  aradRenderAdmin();

  alert("دوره با موفقیت اضافه شد.");
}

function aradGiveGrade() {
  if (!aradIsAdmin()) return;

  const db = aradGetDB();

  const email = document.getElementById("grade-user").value;
  const courseId = document.getElementById("grade-course").value;
  const score = Number(document.getElementById("grade-score").value);
  const description = document.getElementById("grade-description").value.trim();

  const user = (db.users || []).find(u => u.email === email);
  const course = (db.courses || []).find(c => c.id === courseId);

  if (!user || !course || !Number.isFinite(score) || score < 0 || score > 100) {
    alert("دانش‌آموز، دوره و نمره معتبر را انتخاب کن.");
    return;
  }

  db.grades = db.grades || [];

  db.grades.push({
    student: user.name,
    email: user.email,
    course: course.name,
    courseId,
    score,
    description,
    date: new Date().toLocaleDateString("fa-IR")
  });

  aradSaveDB(db);
  aradRenderAdmin();

  alert("نمره دانش‌آموز ثبت شد.");
}

function aradDeleteUser(index) {
  if (!aradIsAdmin()) return;
  if (!confirm("این دانش‌آموز حذف شود؟")) return;

  const db = aradGetDB();

  db.users.splice(index, 1);
  aradSaveDB(db);
  aradRenderAdmin();
}

function aradDeleteCourse(id) {
  if (!aradIsAdmin()) return;
  if (!confirm("این دوره حذف شود؟")) return;

  const db = aradGetDB();

  db.courses = db.courses.filter(course => course.id !== id);
  aradSaveDB(db);
  aradRenderAdmin();
}

function aradDeleteGrade(index) {
  if (!aradIsAdmin()) return;
  if (!confirm("این نمره حذف شود؟")) return;

  const db = aradGetDB();

  db.grades.splice(index, 1);
  aradSaveDB(db);
  aradRenderAdmin();
}

function aradIsAdmin() {
  return sessionStorage.getItem("arad_admin_session") === "active";
}

aradCheckAdmin();
</script>

<!-- ==================================
 ARAD ACADEMY - PART 5
 EXAMS AND STUDENT REPORTS
=================================== -->

<section id="arad-exams" class="page container">

  <div class="panel">
    <span class="badge">ARAD SMART EXAM</span>
    <h1>🧠 مرکز آزمون آکادمی</h1>
    <p>دانش خودت را امتحان کن و نتیجه را در کارنامه ببین.</p>

    <select id="arad-exam-course" class="field">
      <option value="">انتخاب دوره</option>
    </select>

    <button class="btn" onclick="aradStartExam()">
      شروع آزمون
    </button>
  </div>

  <div id="arad-exam-content"></div>

  <div class="panel">
    <h2>📜 کارنامه اختصاصی من</h2>
    <div id="arad-report"></div>

    <button class="btn secondary" onclick="aradRenderReport()">
      بروزرسانی کارنامه
    </button>
  </div>

</section>

<style>
#arad-exams .panel {
  margin: 25px 0;
  padding: 25px;
}

#arad-exams h1 {
  color: #67e8f9;
  text-shadow: 0 0 15px #0891b2;
}

.arad-result-card {
  border: 1px solid #22d3ee;
  background: rgba(8, 30, 55, .8);
  border-radius: 15px;
  padding: 18px;
  margin: 15px 0;
}

.arad-answer {
  display: block;
  width: 100%;
  text-align: right;
  margin: 8px 0;
  padding: 13px;
  border: 1px solid #2563eb;
  border-radius: 10px;
  background: #10213b;
  color: white;
  cursor: pointer;
}

.arad-answer.selected {
  border: 2px solid #22d3ee;
  background: #164e63;
}

.arad-answer.correct {
  background: #14532d;
  border-color: #22c55e;
}

.arad-answer.wrong {
  background: #7f1d1d;
  border-color: #ef4444;
}

.arad-score {
  font-size: 35px;
  color: #67e8f9;
  font-weight: bold;
}

.arad-progress {
  height: 12px;
  background: #1e293b;
  border-radius: 20px;
  overflow: hidden;
  margin: 12px 0;
}

.arad-progress span {
  display: block;
  height: 100%;
  background: linear-gradient(90deg,#06b6d4,#8b5cf6);
}
</style>

<script>
/* ==================================
   ARAD EXAM ENGINE
================================== */

let aradExamState = null;

function aradExamDB() {
  return JSON.parse(
    localStorage.getItem("arad_academy_v2") || "{}"
  );
}

function aradExamSave(db) {
  localStorage.setItem(
    "arad_academy_v2",
    JSON.stringify(db)
  );
}

function aradLoadExamCourses() {
  const db = aradExamDB();

  const select = document.getElementById(
    "arad-exam-course"
  );

  if (!select) return;

  select.innerHTML =
    '<option value="">انتخاب دوره</option>' +
    (db.courses || []).map(c => `
      <option value="${escapeHTML(c.id)}">
        ${escapeHTML(c.name)}
      </option>
    `).join("");
}

function aradStartExam() {
  const db = aradExamDB();

  if (!db.current) {
    alert("ابتدا وارد حساب دانش‌آموزی شو.");
    return;
  }

  const id = document.getElementById(
    "arad-exam-course"
  ).value;

  const course = (db.courses || []).find(
    c => c.id === id
  );

  if (!course) {
    alert("یک دوره انتخاب کن.");
    return;
  }

  if (!course.quiz || course.quiz.length === 0) {
    alert("برای این دوره هنوز آزمونی تعریف نشده است.");
    return;
  }

  aradExamState = {
    courseId: id,
    courseName: course.name,
    questions: course.quiz,
    current: 0,
    answers: []
  };

  aradShowExamQuestion();
}

function aradShowExamQuestion() {
  const state = aradExamState;

  if (!state) return;

  const q = state.questions[state.current];

  document.getElementById(
    "arad-exam-content"
  ).innerHTML = `
    <div class="panel">
      <span class="badge">آزمون آنلاین</span>

      <h2>${escapeHTML(state.courseName)}</h2>

      <p>
        سؤال ${state.current + 1}
        از ${state.questions.length}
      </p>

      <div class="arad-progress">
        <span style="width:${
          ((state.current + 1) / state.questions.length) * 100
        }%"></span>
      </div>

      <h3>${escapeHTML(q[0])}</h3>

      <div id="arad-options">
        ${q[1].map((option, index) => `
          <button
            class="arad-answer ${
              state.answers[state.current] === index
                ? "selected"
                : ""
            }"
            onclick="aradChooseAnswer(${index})"
          >
            ${index + 1}. ${escapeHTML(option)}
          </button>
        `).join("")}
      </div>

      <button class="btn" onclick="aradNextQuestion()">
        ${
          state.current === state.questions.length - 1
            ? "ثبت و پایان آزمون"
            : "سؤال بعدی"
        }
      </button>

      <button class="btn secondary"
        onclick="aradCancelExam()">
        خروج از آزمون
      </button>
    </div>
  `;
}

function aradChooseAnswer(index) {
  if (!aradExamState) return;

  aradExamState.answers[
    aradExamState.current
  ] = index;

  aradShowExamQuestion();
}

function aradNextQuestion() {
  const state = aradExamState;

  if (!state) return;

  if (
    state.answers[state.current] === undefined
  ) {
    alert("ابتدا یک گزینه انتخاب کن.");
    return;
  }

  if (
    state.current < state.questions.length - 1
  ) {
    state.current++;
    aradShowExamQuestion();
  } else {
    aradFinishExam();
  }
}

function aradFinishExam() {
  const state = aradExamState;
  const db = aradExamDB();

  if (!state || !db.current) return;

  let correct = 0;

  state.questions.forEach((question, index) => {
    if (
      state.answers[index] === question[2]
    ) {
      correct++;
    }
  });

  const total = state.questions.length;

  const score = Math.round(
    (correct / total) * 100
  );

  db.quizResults = db.quizResults || {};

  db.quizResults[db.current] =
    db.quizResults[db.current] || [];

  db.quizResults[db.current].push({
    courseId: state.courseId,
    courseName: state.courseName,
    correct,
    total,
    score,
    date: new Date().toLocaleDateString("fa-IR")
  });

  aradExamSave(db);

  let review = "";

  state.questions.forEach((question, index) => {
    const right = question[2];
    const selected = state.answers[index];

    review += `
      <div class="arad-result-card">
        <h3>${escapeHTML(question[0])}</h3>
        <p>
          پاسخ تو:
          ${escapeHTML(question[1][selected])}
        </p>
        <p>
          پاسخ صحیح:
          ${escapeHTML(question[1][right])}
        </p>
        <strong style="color:${
          selected === right ? "#4ade80" : "#f87171"
        }">
          ${selected === right ? "پاسخ صحیح ✓" : "پاسخ اشتباه ✗"}
        </strong>
      </div>
    `;
  });

  document.getElementById(
    "arad-exam-content"
  ).innerHTML = `
    <div class="panel">
      <h1>🏆 نتیجه آزمون</h1>

      <div class="arad-score">${score} از ۱۰۰</div>

      <h3>${correct} پاسخ صحیح از ${total} سؤال</h3>

      <p>
        ${
          score >= 90
            ? "فوق‌العاده! عملکرد عالی داشتی."
            : score >= 70
              ? "آفرین! نتیجه خوبی گرفتی."
              : score >= 50
                ? "خوب است، اما بیشتر تمرین کن."
                : "نیاز به تمرین بیشتری داری."
        }
      </p>

      <h2>بررسی پاسخ‌ها</h2>
      ${review}

      <button class="btn"
        onclick="aradRenderReport()">
        مشاهده کارنامه
      </button>
    </div>
  `;

  aradExamState = null;
  aradRenderReport();
}

function aradCancelExam() {
  if (!confirm("از آزمون خارج می‌شوی؟")) return;

  aradExamState = null;

  document.getElementById(
    "arad-exam-content"
  ).innerHTML = "";
}

function aradRenderReport() {
  const db = aradExamDB();

  const report = document.getElementById(
    "arad-report"
  );

  if (!report) return;

  if (!db.current) {
    report.innerHTML =
      "<p>برای مشاهده کارنامه وارد حساب شو.</p>";
    return;
  }

  const user = (db.users || []).find(
    u => u.email === db.current
  );

  if (!user) {
    report.innerHTML = "<p>حساب دانش‌آموز پیدا نشد.</p>";
    return;
  }

  const results =
    (db.quizResults || {})[db.current] || [];

  const grades = (db.grades || []).filter(
    g => g.email === db.current
  );

  const allScores = [
    ...results.map(r => Number(r.score)),
    ...grades.map(g => Number(g.score))
  ];

  const average = allScores.length
    ? Math.round(
        allScores.reduce((a, b) => a + b, 0) /
        allScores.length
      )
    : 0;

  report.innerHTML = `
    <div class="arad-result-card">
      <h3>👤 ${escapeHTML(user.name)}</h3>
      <p>${escapeHTML(user.email)}</p>

      <div class="grid">
        <div class="stat">
          <strong>${results.length}</strong>
          آزمون انجام‌شده
        </div>

        <div class="stat">
          <strong>${grades.length}</strong>
          نمره مدیر
        </div>

        <div class="stat">
          <strong>${average}</strong>
          میانگین نمرات
        </div>
      </div>
    </div>

    <h3>🧠 نتایج آزمون‌ها</h3>

    ${
      results.map(r => `
        <div class="arad-result-card">
          <strong>${escapeHTML(r.courseName)}</strong>
          <p>نمره: ${r.score} از ۱۰۰</p>
          <p>پاسخ صحیح: ${r.correct} از ${r.total}</p>
          <small>${escapeHTML(r.date)}</small>
        </div>
      `).join("") || "<p>هنوز آزمونی انجام نداده‌ای.</p>"
    }

    <h3>👑 نمرات ثبت‌شده توسط مدیر</h3>

    ${
      grades.map(g => `
        <div class="arad-result-card">
          <strong>${escapeHTML(g.course)}</strong>
          <div class="arad-score">${g.score}/100</div>
          <p>${escapeHTML(g.description || "بدون توضیحات")}</p>
          <small>${escapeHTML(g.date || "")}</small>
        </div>
      `).join("") || "<p>هنوز نمره‌ای از طرف مدیر ثبت نشده است.</p>"
    }
  `;
}

/* INITIALIZE */

aradLoadExamCourses();
aradRenderReport();

</script>

<!-- ========== ARAD ACADEMY - PART 6 ========== -->

<style>
.admin-area {
  display:none;
  padding:25px;
  margin:20px auto;
  max-width:1100px;
}
.admin-area.active {display:block}
.admin-box {
  background:rgba(15,25,50,.88);
  border:1px solid #00d9ff;
  border-radius:18px;
  padding:22px;
  margin:15px 0;
  box-shadow:0 0 20px #00cfff22;
}
.admin-area input,
.admin-area select,
.admin-area textarea {
  display:block;
  width:100%;
  padding:13px;
  margin:10px 0;
  border-radius:9px;
  border:1px solid #00bfff;
  background:#101b32;
  color:white;
}
.admin-area button {
  padding:11px 18px;
  margin:5px;
  border:0;
  border-radius:9px;
  background:#00bfff;
  color:#061326;
  font-weight:bold;
  cursor:pointer;
}
.admin-area .danger {
  background:#ff365e;
  color:white;
}
.admin-area .success {
  background:#00d68f;
}
.admin-area h2 {color:#00d9ff}
.admin-student {
  border:1px solid #263e64;
  padding:15px;
  border-radius:12px;
  margin:12px 0;
}
</style>

<div id="aradAdmin" class="admin-area">

  <div class="admin-box">
    <h1>👑 مدیریت آکادمی اراد</h1>
    <p>پنل اختصاصی مدیر</p>
    <button onclick="aradAdminTab('students')">
      👨‍🎓 دانش‌آموزان
    </button>
    <button onclick="aradAdminTab('grades')">
      📝 نمره‌دهی
    </button>
    <button onclick="aradAdminTab('courses')">
      📚 مدیریت دوره‌ها
    </button>
    <button onclick="aradAdminTab('reports')">
      📊 گزارش‌ها
    </button>
    <button class="danger" onclick="aradAdminLogout()">
      خروج مدیر
    </button>
  </div>

  <div id="aradAdminContent"></div>
</div>

<div id="aradAdminLogin" class="admin-area">
  <div class="admin-box">
    <h2>🔐 ورود مدیر آکادمی</h2>
    <input id="aradAdminPassword"
      type="password"
      placeholder="رمز عبور مدیر">

    <button onclick="aradAdminEnter()">
      ورود به پنل مدیریت
    </button>
    <p id="aradAdminMessage"></p>
  </div>
</div>

<script>
(function(){

const ARAD_ADMIN_PASSWORD = "AradKalantar1392";

const DB_NAME = "arad_admin_records_v1";

function getRecords(){
  try {
    return JSON.parse(localStorage.getItem(DB_NAME)) || {
      grades:[],
      announcements:[]
    };
  } catch {
    return {grades:[],announcements:[]};
  }
}

function saveRecords(data){
  localStorage.setItem(DB_NAME,JSON.stringify(data));
}

function adminIsOpen(){
  return sessionStorage.getItem("arad_admin_session")==="active";
}

window.aradAdminEnter=function(){

  const password =
    document.getElementById("aradAdminPassword").value;

  if(password !== ARAD_ADMIN_PASSWORD){
    document.getElementById("aradAdminMessage").textContent =
      "❌ رمز عبور اشتباه است!";
    return;
  }

  sessionStorage.setItem("arad_admin_session","active");

  document.getElementById("aradAdminLogin")
    .classList.remove("active");

  document.getElementById("aradAdmin")
    .classList.add("active");

  window.aradAdminTab("students");
};

window.aradAdminLogout=function(){
  sessionStorage.removeItem("arad_admin_session");

  document.getElementById("aradAdmin")
    .classList.remove("active");

  document.getElementById("aradAdminLogin")
    .classList.add("active");
};

window.aradAdminTab=function(tab){

  if(!adminIsOpen()) return;

  const content =
    document.getElementById("aradAdminContent");

  const records=getRecords();

  if(tab==="students"){

    let users=[];

    try {
      const oldDB=JSON.parse(
        localStorage.getItem("aradAcademyDB")
      );
      users=oldDB?.users || [];
    } catch {}

    content.innerHTML=`
      <div class="admin-box">
        <h2>👨‍🎓 مدیریت دانش‌آموزان</h2>
        <p>تعداد دانش‌آموزان: ${users.length}</p>
        ${users.map((u,i)=>`
          <div class="admin-student">
            <strong>${aradEscape(u.name)}</strong>
            <p>${aradEscape(u.email)}</p>
            <button onclick="aradSelectStudent(${i})">
              ثبت نمره
            </button>
          </div>
        `).join("") || "<p>هنوز دانش‌آموزی ثبت نشده است.</p>"}
      </div>
    `;

    window.aradSelectStudent=function(i){
      const u=users[i];
      window.aradAdminTab("grades");
      document.getElementById("gradeEmail").value=u.email;
    };
  }

  if(tab==="grades"){

    content.innerHTML=`
      <div class="admin-box">
        <h2>📝 ثبت نمره دانش‌آموز</h2>

        <input id="gradeEmail"
          placeholder="ایمیل دانش‌آموز">

        <input id="gradeCourse"
          placeholder="نام دوره">

        <input id="gradeValue"
          type="number"
          min="0"
          max="100"
          placeholder="نمره از ۱۰۰">

        <textarea id="gradeDescription"
          placeholder="توضیحات مدیر درباره عملکرد دانش‌آموز"></textarea>

        <button class="success"
          onclick="aradSaveGrade()">
          ثبت نمره
        </button>
      </div>

      <div class="admin-box">
        <h2>📋 نمرات ثبت‌شده</h2>
        <div id="aradGradeList">
          ${records.grades.map((g,i)=>`
            <div class="admin-student">
              <strong>${aradEscape(g.email)}</strong>
              <p>دوره: ${aradEscape(g.course)}</p>
              <h2>${g.value} از ۱۰۰</h2>
              <p>${aradEscape(g.description)}</p>
              <button class="danger"
                onclick="aradDeleteGrade(${i})">
                حذف نمره
              </button>
            </div>
          `).join("") || "هنوز نمره‌ای ثبت نشده است."}
        </div>
      </div>
    `;
  }

  if(tab==="courses"){

    content.innerHTML=`
      <div class="admin-box">
        <h2>📚 مدیریت دوره‌ها</h2>
        <p>دوره‌های موجود در آکادمی</p>
        <div id="aradCoursesList"></div>
      </div>
    `;

    let courses=[];

    try {
      const oldDB=JSON.parse(
        localStorage.getItem("aradAcademyDB")
      );
      courses=oldDB?.courses || [];
    } catch {}

    document.getElementById("aradCoursesList").innerHTML=
      courses.map(c=>`
        <div class="admin-student">
          <strong>${aradEscape(c.name)}</strong>
          <p>${aradEscape(c.description || "")}</p>
        </div>
      `).join("") || "دوره‌ای پیدا نشد.";
  }

  if(tab==="reports"){

    const grades=records.grades;
    const average=grades.length
      ? Math.round(grades.reduce((s,g)=>s+g.value,0)/grades.length)
      : 0;

    content.innerHTML=`
      <div class="admin-box">
        <h2>📊 گزارش عملکرد</h2>
        <h3>تعداد نمرات: ${grades.length}</h3>
        <h3>میانگین نمرات: ${average}</h3>
        <p>این گزارش بر اساس نمرات ثبت‌شده در این مرورگر است.</p>
      </div>
    `;
  }
};

window.aradSaveGrade=function(){

  if(!adminIsOpen()) return;

  const email=document.getElementById("gradeEmail").value.trim();
  const course=document.getElementById("gradeCourse").value.trim();
  const value=Number(document.getElementById("gradeValue").value);
  const description=document.getElementById("gradeDescription").value.trim();

  if(!email || !course ||
     document.getElementById("gradeValue").value===""){
    alert("لطفاً اطلاعات نمره را کامل کن.");
    return;
  }

  if(!Number.isFinite(value) || value<0 || value>100){
    alert("نمره باید بین صفر تا صد باشد.");
    return;
  }

  const records=getRecords();

  records.grades.push({
    email,
    course,
    value,
    description,
    date:new Date().toLocaleDateString("fa-IR")
  });

  saveRecords(records);

  alert("✅ نمره با موفقیت ثبت شد.");

  window.aradAdminTab("grades");
};

window.aradDeleteGrade=function(index){

  if(!adminIsOpen()) return;

  if(!confirm("این نمره حذف شود؟")) return;

  const records=getRecords();

  records.grades.splice(index,1);

  saveRecords(records);

  window.aradAdminTab("grades");
};

function aradEscape(value){
  return String(value ?? "").replace(/[&<>"']/g,c=>({
    "&":"&amp;",
    "<":"&lt;",
    ">":"&gt;",
    '"':"&quot;",
    "'":"&#39;"
  })[c]);
}

})();
</script>

<!-- ========== END OF PART 6 ========== -->

<!-- =====================================
 ARAD ACADEMY - PART 7
 STORE & PAYMENT SYSTEM
===================================== -->

<style>
.arad-store {
  max-width:1150px;
  margin:30px auto;
  padding:20px;
  color:white;
}
.arad-store-title {
  text-align:center;
  color:#00e5ff;
  font-size:30px;
  text-shadow:0 0 15px #00cfff;
}
.arad-store-grid {
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
  gap:20px;
  margin-top:25px;
}
.arad-product {
  background:rgba(12,25,49,.88);
  border:1px solid #00cfff66;
  border-radius:18px;
  padding:20px;
  box-shadow:0 0 20px #00bfff18;
  transition:.3s;
}
.arad-product:hover {
  transform:translateY(-5px);
  box-shadow:0 0 25px #00cfff55;
}
.arad-product h3 {color:#00e5ff}
.arad-price {
  font-size:23px;
  color:#00e69a;
  font-weight:bold;
}
.arad-store button {
  border:0;
  border-radius:9px;
  padding:12px 17px;
  margin:5px;
  background:#00cfff;
  color:#061326;
  font-weight:bold;
  cursor:pointer;
}
.arad-store .secondary {
  background:#253d60;
  color:white;
}
.arad-store .store-panel {
  background:#101e38;
  border:1px solid #284d75;
  border-radius:16px;
  padding:20px;
  margin:20px 0;
}
.arad-store input {
  display:block;
  width:100%;
  padding:13px;
  margin:10px 0;
  background:#08172b;
  color:white;
  border:1px solid #00cfff;
  border-radius:8px;
}
.arad-store .notice {
  color:#ffc857;
  font-size:13px;
}
</style>

<div class="arad-store">

  <h1 class="arad-store-title">
    🛒 فروشگاه اختصاصی ARAD ACADEMY
  </h1>

  <p style="text-align:center">
    دانش و مهارتت را با دوره‌های حرفه‌ای ارتقا بده.
  </p>

  <div class="store-panel">
    <h2>💳 حساب کاربری و خریدها</h2>
    <p id="aradStoreUser">برای خرید وارد حساب کاربری شو.</p>
    <p id="aradStoreCount">دوره‌های خریداری‌شده: ۰</p>
    <button onclick="aradShowPurchases()">
      دوره‌های من
    </button>
  </div>

  <h2>📚 دوره‌های قابل خرید</h2>

  <div id="aradStoreProducts" class="arad-store-grid"></div>

  <div class="store-panel">
    <h2>🧾 سبد خرید</h2>
    <div id="aradCartContent">سبد خرید خالی است.</div>
    <h3 id="aradCartTotal">مجموع: ۰ تومان</h3>
    <button onclick="aradCheckout()">ادامه و ثبت سفارش</button>
    <button class="secondary" onclick="aradClearCart()">خالی کردن سبد</button>
  </div>

  <div class="store-panel">
    <h2>📦 سفارش‌های من</h2>
    <div id="aradOrders"></div>
  </div>

  <div class="store-panel">
    <h2>🎬 دوره‌های ویدئویی خریداری‌شده</h2>
    <div id="aradPurchasedCourses">
      هنوز دوره‌ای خریداری نشده است.
    </div>
  </div>

  <div class="store-panel">
    <h2>🔐 پرداخت</h2>
    <p class="notice">
      این نسخه آزمایشی است و هیچ تراکنش بانکی واقعی انجام نمی‌دهد.
      برای پرداخت واقعی باید درگاه رسمی به سرور متصل شود.
    </p>
    <p id="aradPaymentMessage">
      پس از ثبت سفارش، وضعیت آن در این قسمت نمایش داده می‌شود.
    </p>
  </div>

</div>

<script>
(function(){

const STORE_KEY = "arad_academy_store_v1";

const products = [
 {
  id:"python",
  name:"دوره جامع Python",
  description:"آموزش پایتون از مقدماتی تا پیشرفته همراه پروژه.",
  price:50000
 },
 {
  id:"javascript",
  name:"دوره JavaScript",
  description:"ساخت وب‌سایت‌های تعاملی و برنامه‌های مدرن.",
  price:75000
 },
 {
  id:"react",
  name:"دوره React",
  description:"آموزش کامپوننت‌ها، Hooks و طراحی رابط کاربری.",
  price:100000
 },
 {
  id:"backend",
  name:"دوره Backend",
  description:"آموزش API، سرور، دیتابیس و امنیت.",
  price:120000
 },
 {
  id:"telegram",
  name:"ساخت ربات تلگرام",
  description:"ساخت ربات کاربردی با Python.",
  price:85000
 },
 {
  id:"automation",
  name:"اسکریپت‌نویسی و اتوماسیون",
  description:"خودکارسازی کارها و مدیریت فایل‌ها.",
  price:65000
 }
];

function getStore(){
 try{
  return JSON.parse(localStorage.getItem(STORE_KEY)) || {
   carts:{},
   orders:[],
   purchases:{}
  };
 }catch{
  return {carts:{},orders:[],purchases:{}};
 }
}

function saveStore(data){
 localStorage.setItem(STORE_KEY,JSON.stringify(data));
}

function currentUser(){
 try{
  const db=JSON.parse(localStorage.getItem("aradAcademyDB"));
  if(!db || !db.current) return null;
  return db.users.find(u=>u.email===db.current) || null;
 }catch{
  return null;
 }
}

function escapeText(value){
 return String(value ?? "").replace(/[&<>"']/g,c=>({
  "&":"&amp;",
  "<":"&lt;",
  ">":"&gt;",
  '"':"&quot;",
  "'":"&#39;"
 })[c]);
}

function userKey(){
 const user=currentUser();
 return user ? user.email : null;
}

window.aradRenderStore=function(){

 const user=currentUser();

 document.getElementById("aradStoreUser").textContent=
  user ? "خوش آمدی "+user.name : "برای خرید وارد حساب کاربری شو.";

 const data=getStore();
 const key=userKey();

 const purchased=key ? (data.purchases[key] || []) : [];

 document.getElementById("aradStoreCount").textContent=
  "دوره‌های خریداری‌شده: "+purchased.length;

 document.getElementById("aradStoreProducts").innerHTML=
 products.map(p=>`
  <article class="arad-product">
   <h3>📘 ${escapeText(p.name)}</h3>
   <p>${escapeText(p.description)}</p>
   <p class="arad-price">
    ${p.price.toLocaleString("fa-IR")} تومان
   </p>
   <button onclick="aradAddCart('${p.id}')">
    افزودن به سبد خرید
   </button>
  </article>
 `).join("");

 window.aradRenderCart();
 window.aradRenderOrders();
 window.aradShowPurchases();
};

window.aradAddCart=function(id){

 if(!userKey()){
  alert("ابتدا وارد حساب کاربری شو.");
  return;
 }

 const product=products.find(p=>p.id===id);
 if(!product) return;

 const data=getStore();
 const key=userKey();

 data.carts[key]=data.carts[key] || [];

 if(data.carts[key].includes(id)){
  alert("این دوره قبلاً در سبد خرید قرار گرفته است.");
  return;
 }

 const purchased=data.purchases[key] || [];

 if(purchased.includes(id)){
  alert("این دوره را قبلاً خریداری کرده‌ای.");
  return;
 }

 data.carts[key].push(id);
 saveStore(data);

 window.aradRenderCart();

 alert("دوره به سبد خرید اضافه شد.");
};

window.aradRenderCart=function(){

 const key=userKey();
 const data=getStore();
 const cart=key ? (data.carts[key] || []) : [];

 let total=0;

 const html=cart.map(id=>{
  const p=products.find(x=>x.id===id);
  if(!p) return "";
  total+=p.price;

  return `
   <div>
    <strong>${escapeText(p.name)}</strong>
    <span>${p.price.toLocaleString("fa-IR")} تومان</span>
    <button class="secondary"
     onclick="aradRemoveCart('${id}')">حذف</button>
   </div>
  `;
 }).join("");

 document.getElementById("aradCartContent").innerHTML=
  html || "سبد خرید خالی است.";

 document.getElementById("aradCartTotal").textContent=
  "مجموع: "+total.toLocaleString("fa-IR")+" تومان";
};

window.aradRemoveCart=function(id){

 const data=getStore();
 const key=userKey();

 if(!key) return;

 data.carts[key]=(data.carts[key] || []).filter(x=>x!==id);

 saveStore(data);
 window.aradRenderCart();
};

window.aradClearCart=function(){

 const data=getStore();
 const key=userKey();

 if(!key) return;

 data.carts[key]=[];

 saveStore(data);
 window.aradRenderCart();
};

window.aradCheckout=function(){

 const key=userKey();

 if(!key){
  alert("ابتدا وارد حساب کاربری شو.");
  return;
 }

 const data=getStore();
 const cart=data.carts[key] || [];

 if(!cart.length){
  alert("سبد خرید خالی است.");
  return;
 }

 const items=cart.map(id=>products.find(p=>p.id===id)).filter(Boolean);

 const total=items.reduce((sum,p)=>sum+p.price,0);

 const order={
  id:"ARAD-"+Date.now(),
  email:key,
  items:items.map(p=>p.id),
  total,
  status:"در انتظار پرداخت",
  date:new Date().toLocaleString("fa-IR")
 };

 data.orders.push(order);
 data.carts[key]=[];

 saveStore(data);

 document.getElementById("aradPaymentMessage").textContent=
  "سفارش "+order.id+" ثبت شد. مبلغ: "+
  total.toLocaleString("fa-IR")+" تومان. پرداخت هنوز انجام نشده است.";

 window.aradRenderCart();
 window.aradRenderOrders();

 alert("سفارش آزمایشی ثبت شد. هیچ پولی برداشت نشده است.");
};

window.aradRenderOrders=function(){

 const key=userKey();
 const data=getStore();

 const orders=key
  ? data.orders.filter(o=>o.email===key)
  : [];

 document.getElementById("aradOrders").innerHTML=
  orders.map(o=>`
   <div class="store-panel">
    <strong>${escapeText(o.id)}</strong>
    <p>مبلغ: ${o.total.toLocaleString("fa-IR")} تومان</p>
    <p>وضعیت: ${escapeText(o.status)}</p>
    <small>${escapeText(o.date)}</small>
   </div>
  `).join("") || "هنوز سفارشی ثبت نشده است.";
};

window.aradShowPurchases=function(){

 const key=userKey();
 const data=getStore();

 const ids=key ? (data.purchases[key] || []) : [];

 document.getElementById("aradPurchasedCourses").innerHTML=
  ids.map(id=>{
   const p=products.find(x=>x.id===id);
   if(!p) return "";
   return `
    <div class="store-panel">
     <h3>${escapeText(p.name)}</h3>
     <p>دسترسی خریداری‌شده</p>
     <p>ویدئوهای این دوره پس از اتصال محتوای اختصاصی نمایش داده می‌شوند.</p>
    </div>
   `;
  }).join("") || "هنوز دوره‌ای خریداری نشده است.";
};

window.aradRenderStore();

})();
</script>

<!-- ========== END OF PART 7 ========== -->

<!-- =====================================
 ARAD ACADEMY - PART 8
 FINANCIAL MANAGEMENT
===================================== -->

<style>
.arad-finance {
  display:none;
  max-width:1100px;
  margin:30px auto;
  padding:20px;
  color:white;
}
.arad-finance.active {display:block}

.arad-finance .finance-box {
  background:rgba(10,24,48,.95);
  border:1px solid #00d9ff66;
  border-radius:18px;
  padding:22px;
  margin:18px 0;
  box-shadow:0 0 20px #00bfff18;
}
.arad-finance h1,
.arad-finance h2 {
  color:#00dcff;
}
.arad-finance .finance-grid {
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(190px,1fr));
  gap:15px;
}
.arad-finance .finance-stat {
  background:#122744;
  padding:20px;
  border-radius:14px;
  text-align:center;
}
.arad-finance .finance-stat strong {
  display:block;
  font-size:23px;
  color:#00e9a0;
  margin-top:10px;
}
.arad-finance input {
  width:100%;
  padding:13px;
  margin:10px 0;
  background:#08172b;
  color:white;
  border:1px solid #00bfff;
  border-radius:9px;
  box-sizing:border-box;
}
.arad-finance button {
  background:#00cfff;
  color:#061326;
  border:0;
  border-radius:9px;
  padding:12px 18px;
  margin:5px;
  cursor:pointer;
  font-weight:bold;
}
.arad-finance .finance-note {
  color:#ffc857;
  line-height:2;
}
.arad-finance .finance-record {
  background:#122744;
  padding:15px;
  margin:10px 0;
  border-radius:12px;
  overflow-wrap:anywhere;
}
</style>

<div class="arad-finance" id="aradFinance">

  <div class="finance-box">
    <h1>👑 خزانه مالی ARAD ACADEMY</h1>
    <p>پنل مالی اختصاصی مدیر</p>
    <button onclick="aradFinanceRefresh()">به‌روزرسانی اطلاعات</button>
    <button onclick="aradFinanceClose()">خروج</button>
  </div>

  <div class="finance-grid">

    <div class="finance-stat">
      فروش تأییدشده
      <strong id="financeSales">۰ تومان</strong>
    </div>

    <div class="finance-stat">
      سفارش‌های ثبت‌شده
      <strong id="financeOrders">۰</strong>
    </div>

    <div class="finance-stat">
      تعداد تراکنش‌های موفق
      <strong id="financePaid">۰</strong>
    </div>

    <div class="finance-stat">
      درخواست‌های برداشت
      <strong id="financeWithdrawals">۰</strong>
    </div>

  </div>

  <div class="finance-box">
    <h2>💳 اطلاعات تسویه مدیر</h2>

    <p class="finance-note">
      برای امنیت، شماره کارت کامل را در این نسخه ذخیره نمی‌کنیم.
      اطلاعات حساب مقصد باید در پنل امن سرویس پرداخت ثبت و تأیید شود.
    </p>

    <input
      id="financeCardLast4"
      maxlength="4"
      inputmode="numeric"
      placeholder="چهار رقم آخر کارت مدیر"
    >

    <button onclick="aradSaveCardReference()">
      ثبت شناسه کارت
    </button>

    <p id="financeCardStatus"></p>
  </div>

  <div class="finance-box">
    <h2>💰 درخواست برداشت درآمد</h2>

    <p>
      موجودی فروش تأییدشده:
      <strong id="financeBalance">۰ تومان</strong>
    </p>

    <input
      id="financeAmount"
      type="number"
      min="1"
      placeholder="مبلغ درخواست برداشت به تومان"
    >

    <button onclick="aradRequestWithdrawal()">
      ثبت درخواست برداشت
    </button>

    <p class="finance-note">
      این عملیات فقط درخواست محلی ثبت می‌کند و هیچ انتقال وجهی انجام نمی‌دهد.
      برداشت واقعی باید توسط سرویس پرداخت و پس از تأیید سرور انجام شود.
    </p>
  </div>

  <div class="finance-box">
    <h2>📊 تاریخچه سفارش‌ها</h2>
    <div id="financeOrderList"></div>
  </div>

  <div class="finance-box">
    <h2>📤 تاریخچه درخواست‌های برداشت</h2>
    <div id="financeWithdrawalList"></div>
  </div>

</div>

<script>
(function(){

const FINANCE_KEY = "arad_academy_store_v1";
const CARD_KEY = "arad_finance_card_reference";

function isAdmin(){
  return sessionStorage.getItem("arad_admin_session")==="active";
}

function getData(){
  try{
    return JSON.parse(localStorage.getItem(FINANCE_KEY)) || {
      carts:{},
      orders:[],
      purchases:{},
      withdrawals:[]
    };
  }catch{
    return {
      carts:{},
      orders:[],
      purchases:{},
      withdrawals:[]
    };
  }
}

function saveData(data){
  localStorage.setItem(FINANCE_KEY,JSON.stringify(data));
}

function money(value){
  return Number(value || 0).toLocaleString("fa-IR")+" تومان";
}

function safe(value){
  return String(value ?? "").replace(/[&<>"']/g,c=>({
    "&":"&amp;",
    "<":"&lt;",
    ">":"&gt;",
    '"':"&quot;",
    "'":"&#39;"
  })[c]);
}

window.aradFinanceOpen=function(){

  if(!isAdmin()){
    alert("ابتدا با حساب مدیر وارد شو.");
    return;
  }

  document.getElementById("aradFinance").classList.add("active");
  window.aradFinanceRefresh();
};

window.aradFinanceClose=function(){
  document.getElementById("aradFinance").classList.remove("active");
};

window.aradSaveCardReference=function(){

  if(!isAdmin()) return;

  const last4=document.getElementById("financeCardLast4").value.trim();

  if(!/^[0-9]{4}$/.test(last4)){
    alert("چهار رقم آخر کارت را صحیح وارد کن.");
    return;
  }

  localStorage.setItem(CARD_KEY,last4);

  document.getElementById("financeCardStatus").textContent=
    "شناسه کارت با چهار رقم پایانی "+last4+" ثبت شد.";

  alert("شناسه کارت ثبت شد. این ثبت، حساب بانکی را به درگاه متصل نمی‌کند.");
};

window.aradRequestWithdrawal=function(){

  if(!isAdmin()) return;

  const amount=Number(
    document.getElementById("financeAmount").value
  );

  const data=getData();

  const balance=data.orders
    .filter(o=>o.status==="paid")
    .reduce((sum,o)=>sum+Number(o.total || 0),0);

  if(!Number.isSafeInteger(amount) || amount<=0){
    alert("مبلغ معتبر وارد کن.");
    return;
  }

  if(amount>balance){
    alert("مبلغ درخواست از فروش تأییدشده بیشتر است.");
    return;
  }

  data.withdrawals=data.withdrawals || [];

  data.withdrawals.push({
    id:"WD-"+Date.now(),
    amount:amount,
    status:"در انتظار بررسی سرور",
    date:new Date().toLocaleString("fa-IR")
  });

  saveData(data);

  document.getElementById("financeAmount").value="";

  alert("درخواست محلی ثبت شد؛ هنوز برداشت واقعی انجام نشده است.");

  window.aradFinanceRefresh();
};

window.aradFinanceRefresh=function(){

  if(!isAdmin()) return;

  const data=getData();
  const orders=data.orders || [];
  const withdrawals=data.withdrawals || [];

  const paid=orders.filter(o=>o.status==="paid");

  const sales=paid.reduce(
    (sum,o)=>sum+Number(o.total || 0),0
  );

  document.getElementById("financeSales").textContent=money(sales);
  document.getElementById("financeBalance").textContent=money(sales);
  document.getElementById("financeOrders").textContent=orders.length;
  document.getElementById("financePaid").textContent=paid.length;
  document.getElementById("financeWithdrawals").textContent=withdrawals.length;

  document.getElementById("financeOrderList").innerHTML=
    orders.map(o=>`
      <div class="finance-record">
        <strong>${safe(o.id)}</strong>
        <p>کاربر: ${safe(o.email)}</p>
        <p>مبلغ: ${money(o.total)}</p>
        <p>وضعیت: ${safe(o.status)}</p>
        <p>تاریخ: ${safe(o.date)}</p>
      </div>
    `).join("") || "هنوز سفارشی وجود ندارد.";

  document.getElementById("financeWithdrawalList").innerHTML=
    withdrawals.map(w=>`
      <div class="finance-record">
        <strong>${safe(w.id)}</strong>
        <p>مبلغ: ${money(w.amount)}</p>
        <p>وضعیت: ${safe(w.status)}</p>
        <p>تاریخ: ${safe(w.date)}</p>
      </div>
    `).join("") || "درخواستی ثبت نشده است.";

  const card=localStorage.getItem(CARD_KEY);

  document.getElementById("financeCardStatus").textContent=
    card ? "شناسه کارت ثبت‌شده: **** "+card : "شناسه کارتی ثبت نشده است.";
};

})();
</script>

<!-- END OF PART 8 -->

<!-- ================= PART 9 ================= -->
<style>
.arad-dashboard {
 direction:rtl;
 color:white;
 padding:25px;
 font-family:Tahoma,sans-serif;
}
.arad-dashboard h1 {
 color:#00eaff;
 text-shadow:0 0 15px #00eaff;
}
.arad-dash-grid {
 display:grid;
 grid-template-columns:repeat(auto-fit,minmax(190px,1fr));
 gap:18px;
 margin:25px 0;
}
.arad-stat-card,.arad-dash-panel {
 padding:22px;
 border:1px solid #00dfff55;
 border-radius:18px;
 background:rgba(10,25,55,.82);
 backdrop-filter:blur(15px);
 box-shadow:0 0 18px #00dfff18;
}
.arad-stat-card {
 transition:.3s;
}
.arad-stat-card:hover {
 transform:translateY(-5px);
 box-shadow:0 0 25px #00dfff55;
}
.arad-stat-card h3,.arad-dash-panel h2 {
 color:#00eaff;
}
.arad-stat-card strong {
 display:block;
 font-size:30px;
 margin-top:12px;
}
.arad-progress-track {
 background:#17243b;
 height:13px;
 border-radius:20px;
 overflow:hidden;
}
.arad-progress-fill {
 height:100%;
 width:0;
 background:linear-gradient(90deg,#007cf0,#00eaff);
 box-shadow:0 0 12px #00eaff;
 transition:width 1s;
}
.arad-dash-panel {
 margin:20px 0;
}
.arad-dash-button {
 background:linear-gradient(90deg,#007cf0,#00eaff);
 color:#001323;
 border:0;
 padding:12px 20px;
 border-radius:10px;
 cursor:pointer;
 font-weight:bold;
 margin:8px 0;
}
.arad-last-lesson {
 padding:14px;
 border-radius:12px;
 background:#101f38;
 margin-top:12px;
}
@media(max-width:600px) {
 .arad-dashboard {padding:12px}
 .arad-dash-grid {grid-template-columns:1fr 1fr}
 .arad-stat-card {padding:14px}
 .arad-stat-card strong {font-size:23px}
}
</style>

<section class="arad-dashboard" id="aradProfessionalDashboard">

 <h1 id="aradDashWelcome">🚀 داشبورد دانش‌آموز</h1>
 <p>به مرکز یادگیری آکادمی اراد خوش آمدی.</p>

 <div class="arad-dash-grid">
  <div class="arad-stat-card">
   <h3>📚 کل دوره‌ها</h3>
   <strong id="aradDashCourses">0</strong>
  </div>
  <div class="arad-stat-card">
   <h3>✅ درس‌های تکمیل‌شده</h3>
   <strong id="aradDashDone">0</strong>
  </div>
  <div class="arad-stat-card">
   <h3>🏆 امتیاز دانش‌آموز</h3>
   <strong id="aradDashPoints">0</strong>
  </div>
  <div class="arad-stat-card">
   <h3>⏱ ساعات مطالعه</h3>
   <strong id="aradDashHours">0</strong>
  </div>
 </div>

 <div class="arad-dash-panel">
  <h2>📈 پیشرفت کلی یادگیری</h2>
  <div class="arad-progress-track">
   <div class="arad-progress-fill" id="aradDashProgress"></div>
  </div>
  <p id="aradDashPercent">۰٪ تکمیل شده</p>
 </div>

 <div class="arad-dash-panel">
  <h2>📖 آخرین درس</h2>
  <div class="arad-last-lesson">
   <strong id="aradLastLesson">هنوز درسی مطالعه نشده است.</strong>
   <p id="aradLastCourse">دوره‌ای انتخاب نشده است.</p>
  </div>
 </div>

 <div class="arad-dash-panel">
  <h2>🥇 رتبه آموزشی</h2>
  <p id="aradDashRank">🥉 تازه‌کار</p>
  <p>با تکمیل درس‌ها و آزمون‌ها امتیاز بیشتری کسب کن.</p>
 </div>

 <button class="arad-dash-button"
         onclick="aradRefreshDashboard()">
  🔄 بروزرسانی داشبورد
 </button>
</section>

<script>
/* اتصال به دیتابیس محلی آکادمی */

function aradSaveLastLesson(course,lesson) {
 localStorage.setItem(
  "aradLastLesson",
  JSON.stringify({course,lesson})
 );
}

function aradRefreshDashboard() {

 if(typeof db==="undefined" || !db) return;

 const courses=db.courses||[];
 const progress=db.progress||{};
 const currentUser=(db.users||[]).find(
  u=>u.email===db.current
 );

 let totalLessons=0;
 let completedLessons=0;

 courses.forEach(course=>{
  course.chapters.forEach(chapter=>{
   totalLessons+=chapter.lessons.length;
  });
  completedLessons+=
   (progress[course.id]||[]).length;
 });

 const percent=totalLessons
  ?Math.round(completedLessons/totalLessons*100):0;

 document.getElementById("aradDashCourses").textContent=
  courses.length;

 document.getElementById("aradDashDone").textContent=
  completedLessons;

 document.getElementById("aradDashProgress").style.width=
  percent+"%";

 document.getElementById("aradDashPercent").textContent=
  percent+"٪ تکمیل شده";

 const last=JSON.parse(
  localStorage.getItem("aradLastLesson")||"null"
 );

 document.getElementById("aradLastLesson").textContent=
  last?.lesson||"هنوز درسی مطالعه نشده است.";

 document.getElementById("aradLastCourse").textContent=
  last?.course||"دوره‌ای انتخاب نشده است.";

 let points=completedLessons*10;

 Object.values(db.scores||{}).forEach(scores=>{
  scores.forEach(item=>{
   points+=Math.round(
    item.score/Math.max(item.total,1)*100
   );
  });
 });

 document.getElementById("aradDashPoints").textContent=
  points;

 const hours=Number(
  localStorage.getItem("aradStudyHours")||0
 );

 document.getElementById("aradDashHours").textContent=
  hours;

 let rank="🥉 تازه‌کار";
 if(points>=1000) rank="💎 استاد ارشد";
 else if(points>=500) rank="🥇 حرفه‌ای";
 else if(points>=200) rank="🥈 متوسط";
 else if(points>=50) rank="🌟 فعال";

 document.getElementById("aradDashRank").textContent=rank;

 document.getElementById("aradDashWelcome").textContent=
  currentUser
   ?"🚀 داشبورد "+currentUser.name
   :"🚀 داشبورد دانش‌آموز";
}

/* اتصال خودکار به صفحه درس قبلی */
(function(){
 const originalOpenLesson=window.openLesson;

 if(typeof originalOpenLesson==="function"){
  window.openLesson=function(id,ci,li){
   const course=db.courses.find(x=>x.id===id);
   if(course && course.chapters[ci]?.lessons[li]){
    aradSaveLastLesson(
     course.name,
     course.chapters[ci].lessons[li].title
    );
   }
   const result=originalOpenLesson.apply(this,arguments);
   aradRefreshDashboard();
   return result;
  };
 }
})();

/* اتصال به تکمیل درس */
(function(){
 const originalCompleteLesson=window.completeLesson;

 if(typeof originalCompleteLesson==="function"){
  window.completeLesson=function(){
   const result=originalCompleteLesson.apply(this,arguments);
   aradRefreshDashboard();
   return result;
  };
})();

aradRefreshDashboard();
</script>

<!-- END OF PART 9 -->

/* ==========================================
   ARAD ACADEMY - PART 10
   ONLINE CODING PLAYGROUND
========================================== */

(function () {
  if (document.getElementById("aradPlayground")) return;

  const style = document.createElement("style");

  style.textContent = `
    #aradPlayground {
      direction: rtl;
      background: rgba(8, 15, 35, .96);
      border: 1px solid #00eaff;
      border-radius: 22px;
      padding: 22px;
      margin: 25px auto;
      color: white;
      max-width: 1100px;
      box-shadow: 0 0 30px #00d9ff22;
    }

    #aradPlayground h2 {
      color: #00eaff;
      text-shadow: 0 0 15px #00eaff;
    }

    #aradPlayground textarea {
      width: 100%;
      min-height: 180px;
      resize: vertical;
      background: #050b19;
      color: #65f7ff;
      border: 1px solid #176c91;
      border-radius: 12px;
      padding: 15px;
      font-family: monospace;
      direction: ltr;
      box-sizing: border-box;
      margin: 8px 0;
      font-size: 14px;
    }

    #aradPlayground button {
      background: linear-gradient(90deg,#0879d8,#00d9ff);
      color: white;
      border: none;
      padding: 12px 20px;
      border-radius: 10px;
      cursor: pointer;
      margin: 5px;
      font-weight: bold;
    }

    #aradPlayground button:hover {
      box-shadow: 0 0 18px #00d9ff;
      transform: translateY(-2px);
    }

    #aradPlayground iframe {
      width: 100%;
      height: 350px;
      background: white;
      border: 2px solid #00d9ff;
      border-radius: 12px;
      margin-top: 12px;
    }

    #aradPlayground label {
      display: block;
      color: #8eeeff;
      margin-top: 15px;
    }
  `;

  document.head.appendChild(style);

  const section = document.createElement("section");

  section.id = "aradPlayground";

  section.innerHTML = `
    <h2>💻 آزمایشگاه کدنویسی اراد</h2>
    <p>کد بنویس، اجرا کن و نتیجه را مشاهده کن.</p>

    <label>HTML</label>
    <textarea id="aradHTML" spellcheck="false"><h1>Hello ARAD Academy</h1>
<p>My first project!</p>
<button onclick="alert('Welcome!')">Click Me</button></textarea>

    <label>CSS</label>
    <textarea id="aradCSS" spellcheck="false">body {
  background: #101a35;
  color: white;
  text-align: center;
  font-family: Arial;
  padding: 30px;
}

h1 {
  color: #00eaff;
}</textarea>

    <label>JavaScript</label>
    <textarea id="aradJS" spellcheck="false">console.log("ARAD ACADEMY");

document.body.style.borderTop =
  "5px solid cyan";</textarea>

    <button id="aradRun">▶ اجرای پروژه</button>
    <button id="aradClear">🗑 پاک کردن</button>
    <button id="aradExample">📘 نمونه آماده</button>

    <h3>🖥 خروجی پروژه</h3>

    <iframe
      id="aradPreview"
      title="Project preview"
      sandbox="allow-scripts">
    </iframe>

    <p id="aradPlayStatus">آماده اجرای کد هستی!</p>
  `;

  const target =
    document.getElementById("projects") ||
    document.getElementById("courseDetail") ||
    document.querySelector("main") ||
    document.body;

  target.appendChild(section);

  const get = id => document.getElementById(id);

  get("aradRun").addEventListener("click", function () {
    const html = get("aradHTML").value;
    const css = get("aradCSS").value;
    const js = get("aradJS").value;

    const preview = get("aradPreview");

    const documentCode = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <style>${css.replace(/<\/style/gi, "<\\/style")}</style>
      </head>
      <body>
        ${html.replace(/<\/body/gi, "<\\/body")}
        <script>
          try {
            ${js.replace(/<\/script/gi, "<\\/script")}
          } catch (error) {
            document.body.insertAdjacentHTML(
              "beforeend",
              "<pre style='color:red'></pre>"
            );
            document.querySelector("pre").textContent =
              error.message;
          }
        <\/script>
      </body>
      </html>
    `;

    preview.srcdoc = documentCode;

    get("aradPlayStatus").textContent =
      "✅ پروژه اجرا شد!";
  });

  get("aradClear").addEventListener("click", function () {
    get("aradHTML").value = "";
    get("aradCSS").value = "";
    get("aradJS").value = "";
    get("aradPreview").srcdoc = "";
    get("aradPlayStatus").textContent =
      "ویرایشگر پاک شد.";
  });

  get("aradExample").addEventListener("click", function () {
    get("aradHTML").value =
      "<h1>ARAD ACADEMY</h1><p>Welcome to programming!</p>";

    get("aradCSS").value =
      "body {background:#101a35;color:#00eaff;text-align:center;padding:50px;font-family:Arial;}";

    get("aradJS").value =
      "console.log('Hello ARAD!');";
      
    get("aradPlayStatus").textContent =
      "نمونه آماده بارگذاری شد.";
  });

  console.log("ARAD PLAYGROUND PART 10 READY");

})();

/* ==========================================
   ARAD ACADEMY - PART 11
   POINTS & LEADERBOARD SYSTEM
========================================== */

(function () {
  if (document.getElementById("aradRanking")) return;

  const STORAGE_KEY = "arad_ranking_v11";

  let ranking = {};

  try {
    ranking = JSON.parse(
      localStorage.getItem(STORAGE_KEY) || "{}"
    );
  } catch {
    ranking = {};
  }

  function saveRanking() {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(ranking)
    );
  }

  function currentUser() {
    if (typeof db !== "undefined" && db.current) {
      const user = db.users.find(
        u => u.email === db.current
      );

      if (user) return user.email;
    }

    return null;
  }

  function getUser() {
    const email = currentUser();

    if (!email) return null;

    if (!ranking[email]) {
      ranking[email] = {
        points: 0,
        lessons: 0,
        exams: 0,
        badges: []
      };
    }

    return ranking[email];
  }

  function level(points) {
    if (points >= 2000) return "استاد ارشد";
    if (points >= 1000) return "استاد";
    if (points >= 500) return "حرفه‌ای";
    if (points >= 200) return "متوسط";
    return "مبتدی";
  }

  function awardPoints(amount, reason) {
    const user = getUser();

    if (!user) {
      alert("ابتدا وارد حساب دانش‌آموزی شو.");
      return;
    }

    user.points += amount;

    saveRanking();
    render();

    alert(
      amount + " امتیاز دریافت کردی!\n" + reason
    );
  }

  function render() {
    const user = getUser();

    const panel = document.getElementById(
      "aradRanking"
    );

    if (!panel) return;

    if (!user) {
      panel.innerHTML = `
        <h2>🏆 رتبه‌بندی آکادمی اراد</h2>
        <p>برای مشاهده امتیازات وارد حساب شو.</p>
      `;
      return;
    }

    const email = currentUser();

    const sorted = Object.entries(ranking)
      .sort((a, b) => b[1].points - a[1].points);

    const rank = sorted.findIndex(
      item => item[0] === email
    ) + 1;

    panel.innerHTML = `
      <div class="arad-rank-profile">
        <h2>🏆 مرکز افتخارات اراد</h2>

        <div class="arad-rank-number">
          ${user.points}
        </div>

        <h3>امتیاز شما</h3>

        <p>سطح: ${level(user.points)}</p>

        <p>رتبه شما: ${rank}</p>

        <p>درس‌های امتیازدار: ${user.lessons}</p>

        <p>آزمون‌های امتیازدار: ${user.exams}</p>
      </div>

      <h3>🥇 جدول برترین دانش‌آموزان</h3>

      <div class="arad-leader-list">
        ${
          sorted.length
            ? sorted.map((item, index) => `
              <div class="arad-leader-item">
                <span>
                  ${index === 0 ? "🥇" :
                    index === 1 ? "🥈" :
                    index === 2 ? "🥉" :
                    index + 1}
                </span>

                <span>
                  ${escapeHTML(
                    item[0].split("@")[0]
                  )}
                </span>

                <strong>
                  ${item[1].points} امتیاز
                </strong>
              </div>
            `).join("")
            : "<p>هنوز امتیازی ثبت نشده است.</p>"
        }
      </div>

      <h3>🎖 نشان‌های افتخار</h3>

      <div class="arad-badges">
        ${
          user.points >= 100
            ? "<span>🌟 تلاشگر</span>"
            : ""
        }

        ${
          user.points >= 500
            ? "<span>🔥 حرفه‌ای</span>"
            : ""
        }

        ${
          user.points >= 1000
            ? "<span>👑 استاد</span>"
            : ""
        }

        ${
          user.points < 100
            ? "<span>🌱 شروع یادگیری</span>"
            : ""
        }
      </div>
    `;
  }

  const style = document.createElement("style");

  style.textContent = `
    #aradRanking {
      direction: rtl;
      margin: 25px auto;
      max-width: 1050px;
      padding: 25px;
      color: white;
      border: 1px solid #00eaff;
      border-radius: 22px;
      background: rgba(8,15,35,.94);
      box-shadow: 0 0 25px #00dfff22;
    }

    #aradRanking h2 {
      color: #00eaff;
      text-shadow: 0 0 12px #00eaff;
    }

    .arad-rank-profile {
      text-align: center;
      padding: 25px;
      border-radius: 18px;
      background: linear-gradient(
        135deg,
        #101c42,
        #092c43
      );
    }

    .arad-rank-number {
      font-size: 55px;
      font-weight: bold;
      color: #00eaff;
      text-shadow: 0 0 20px #00eaff;
    }

    .arad-leader-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 14px;
      margin: 8px 0;
      border: 1px solid #145c78;
      border-radius: 12px;
      background: #101c35;
      flex-wrap: wrap;
    }

    .arad-leader-item strong {
      color: #00eaff;
    }

    .arad-badges span {
      display: inline-block;
      padding: 12px;
      margin: 5px;
      border: 1px solid #00eaff;
      border-radius: 12px;
      color: #00eaff;
    }
  `;

  document.head.appendChild(style);

  const section = document.createElement("section");
  section.id = "aradRanking";

  const target =
    document.getElementById("dashboardContent") ||
    document.querySelector("main") ||
    document.body;

  target.appendChild(section);

  // اتصال به تکمیل درس‌ها
  const oldCompleteLesson = window.completeLesson;

  if (
    typeof oldCompleteLesson === "function" &&
    !oldCompleteLesson._aradWrapped
  ) {
    const wrapped = function (id, index) {
      const email = currentUser();
      const user = getUser();

      const key = "lesson_" + id + "_" + index;

      if (
        email &&
        user &&
        !localStorage.getItem(
          "arad_award_" + key + "_" + email
        )
      ) {
        oldCompleteLesson(id, index);

        user.points += 10;
        user.lessons++;

        localStorage.setItem(
          "arad_award_" + key + "_" + email,
          "1"
        );

        saveRanking();
        render();

        alert("۱۰ امتیاز برای تکمیل درس گرفتی!");
        return;
      }

      oldCompleteLesson(id, index);
    };

    wrapped._aradWrapped = true;
    window.completeLesson = wrapped;
  }

  // اتصال به آزمون‌ها
  const oldStartQuiz = window.startQuiz;

  if (
    typeof oldStartQuiz === "function" &&
    !oldStartQuiz._aradWrapped
  ) {
    const wrappedQuiz = function (id) {
      oldStartQuiz(id);
    };

    wrappedQuiz._aradWrapped = true;
    window.startQuiz = wrappedQuiz;
  }

  window.aradAwardPoints = awardPoints;
  window.aradRankingRefresh = render;

  render();

  console.log("ARAD PART 11 READY");

})();

/* ==========================================
   ARAD ACADEMY - PART 12
   VIDEO CLASSROOM SYSTEM
========================================== */

(function () {
  if (document.getElementById("aradVideoClass")) return;

  const KEY = "arad_video_progress_v12";

  function getProgress() {
    try {
      return JSON.parse(localStorage.getItem(KEY) || "{}");
    } catch {
      return {};
    }
  }

  function saveProgress(data) {
    localStorage.setItem(KEY, JSON.stringify(data));
  }

  const style = document.createElement("style");

  style.textContent = `
    #aradVideoClass {
      direction: rtl;
      max-width: 1100px;
      margin: 25px auto;
      padding: 24px;
      color: white;
      background: rgba(7,15,35,.97);
      border: 1px solid #00eaff;
      border-radius: 22px;
      box-shadow: 0 0 30px #00eaff22;
    }

    #aradVideoClass h2 {
      color: #00eaff;
      text-shadow: 0 0 12px #00eaff;
    }

    #aradVideoClass select,
    #aradVideoClass input {
      background: #101d38;
      color: white;
      border: 1px solid #087eaa;
      padding: 12px;
      border-radius: 10px;
      margin: 8px 0;
      max-width: 100%;
    }

    #aradVideoClass button {
      background: linear-gradient(90deg,#0879d8,#00d9ff);
      color: white;
      border: 0;
      border-radius: 10px;
      padding: 12px 18px;
      margin: 6px;
      cursor: pointer;
    }

    #aradVideoClass video {
      width: 100%;
      max-height: 500px;
      background: black;
      border: 2px solid #00eaff;
      border-radius: 15px;
      margin-top: 15px;
    }

    #aradVideoClass .video-panel {
      background: #101c35;
      border: 1px solid #145c78;
      padding: 16px;
      border-radius: 14px;
      margin-top: 15px;
    }

    #aradVideoClass textarea {
      width: 100%;
      min-height: 100px;
      background: #050b19;
      color: white;
      border: 1px solid #087eaa;
      border-radius: 10px;
      padding: 12px;
      box-sizing: border-box;
    }

    #aradVideoClass .video-progress {
      height: 8px;
      background: #182b48;
      border-radius: 10px;
      overflow: hidden;
    }

    #aradVideoClass .video-progress span {
      display: block;
      height: 100%;
      background: #00eaff;
      width: 0%;
    }
  `;

  document.head.appendChild(style);

  const section = document.createElement("section");
  section.id = "aradVideoClass";

  section.innerHTML = `
    <h2>🎬 کلاس آنلاین آکادمی اراد</h2>

    <p>به کلاس ویدئویی اختصاصی خودت خوش آمدی.</p>

    <div class="video-panel">
      <h3>📚 انتخاب جلسه</h3>

      <select id="aradVideoCourse">
        <option value="">انتخاب دوره</option>
      </select>

      <select id="aradVideoLesson">
        <option value="">انتخاب درس</option>
      </select>

      <input
        type="url"
        id="aradVideoURL"
        placeholder="آدرس مستقیم فایل ویدئو (MP4)"
      >

      <button id="aradLoadVideo">
        ▶ بارگذاری ویدئو
      </button>
    </div>

    <video id="aradVideoPlayer" controls playsinline>
      مرورگر شما از پخش ویدئو پشتیبانی نمی‌کند.
    </video>

    <div class="video-panel">
      <h3>⏱ پیشرفت تماشا</h3>

      <div class="video-progress">
        <span id="aradVideoBar"></span>
      </div>

      <p id="aradVideoTime">هنوز ویدئویی پخش نشده است.</p>

      <label>سرعت پخش:</label>

      <select id="aradVideoSpeed">
        <option value="0.5">0.5x</option>
        <option value="0.75">0.75x</option>
        <option value="1" selected>1x</option>
        <option value="1.25">1.25x</option>
        <option value="1.5">1.5x</option>
        <option value="2">2x</option>
      </select>

      <button id="aradVideoBookmark">
        🔖 ذخیره نشانک
      </button>

      <button id="aradVideoResume">
        ⏩ ادامه از نشانک
      </button>
    </div>

    <div class="video-panel">
      <h3>📝 متن و زیرنویس درس</h3>

      <textarea
        id="aradVideoNotes"
        placeholder="متن درس یا یادداشت خود را اینجا بنویس..."
      ></textarea>

      <input
        type="url"
        id="aradSubtitleURL"
        placeholder="آدرس فایل زیرنویس VTT (اختیاری)"
      >

      <button id="aradSubtitleLoad">
        فعال‌سازی زیرنویس
      </button>

      <button id="aradSaveNotes">
        ذخیره یادداشت
      </button>
    </div>

    <p id="aradVideoMessage">
      آماده شروع کلاس هستی! 🚀
    </p>
  `;

  const target =
    document.getElementById("dashboardContent") ||
    document.querySelector("main") ||
    document.body;

  target.appendChild(section);

  const $ = id => document.getElementById(id);

  const courses = (
    typeof db !== "undefined" && Array.isArray(db.courses)
  ) ? db.courses : [];

  courses.forEach(course => {
    const option = document.createElement("option");
    option.value = course.id;
    option.textContent = course.name;
    $("aradVideoCourse").appendChild(option);
  });

  let activeKey = "";

  $("aradVideoCourse").addEventListener("change", function () {
    const course = courses.find(c => c.id === this.value);

    $("aradVideoLesson").innerHTML =
      '<option value="">انتخاب درس</option>';

    if (!course) return;

    course.chapters.forEach((chapter, ci) => {
      chapter.lessons.forEach((lesson, li) => {
        const option = document.createElement("option");
        option.value = ci + ":" + li;
        option.textContent =
          chapter.title + " - " + lesson.title;

        $("aradVideoLesson").appendChild(option);
      });
    });
  });

  $("aradLoadVideo").addEventListener("click", function () {
    const courseId = $("aradVideoCourse").value;
    const lessonValue = $("aradVideoLesson").value;
    const url = $("aradVideoURL").value.trim();

    if (!courseId || !lessonValue || !url) {
      alert("دوره، درس و آدرس ویدئو را وارد کن.");
      return;
    }

    try {
      const parsed = new URL(url);

      if (!["https:", "http:"].includes(parsed.protocol)) {
        throw new Error("Invalid URL");
      }
    } catch {
      alert("آدرس ویدئو معتبر نیست.");
      return;
    }

    activeKey = courseId + "_" + lessonValue;

    const progress = getProgress();

    const player = $("aradVideoPlayer");

    player.src = url;
    player.load();

    player.addEventListener("loadedmetadata", function restore() {
      player.removeEventListener("loadedmetadata", restore);

      const saved = progress[activeKey];

      if (saved && saved.time > 0 && saved.time < player.duration) {
        player.currentTime = saved.time;
      }
    });

    $("aradVideoMessage").textContent =
      "ویدئو بارگذاری شد. برای پخش دکمه Play را بزن.";
  });

  $("aradVideoPlayer").addEventListener("timeupdate", function () {
    const player = this;

    if (!activeKey || !Number.isFinite(player.duration)) return;

    const progress = getProgress();

    const percent =
      player.duration ? player.currentTime / player.duration * 100 : 0;

    $("aradVideoBar").style.width = percent + "%";

    $("aradVideoTime").textContent =
      Math.floor(player.currentTime) + " ثانیه از " +
      Math.floor(player.duration) + " ثانیه";

    progress[activeKey] = progress[activeKey] || {};

    progress[activeKey].time = player.currentTime;
    progress[activeKey].percent = percent;

    saveProgress(progress);
  });

  $("aradVideoSpeed").addEventListener("change", function () {
    $("aradVideoPlayer").playbackRate = Number(this.value);
  });

  $("aradVideoBookmark").addEventListener("click", function () {
    if (!activeKey) {
      alert("ابتدا یک ویدئو بارگذاری کن.");
      return;
    }

    const progress = getProgress();

    progress[activeKey] = progress[activeKey] || {};

    progress[activeKey].bookmark =
      $("aradVideoPlayer").currentTime;

    saveProgress(progress);

    $("aradVideoMessage").textContent =
      "نشانک با موفقیت ذخیره شد. 🔖";
  });

  $("aradVideoResume").addEventListener("click", function () {
    const progress = getProgress();

    if (!activeKey || !progress[activeKey]?.bookmark) {
      alert("نشانکی برای این ویدئو ذخیره نشده است.");
      return;
    }

    $("aradVideoPlayer").currentTime =
      progress[activeKey].bookmark;

    $("aradVideoMessage").textContent =
      "به محل نشانک منتقل شدی.";
  });

  $("aradSubtitleLoad").addEventListener("click", function () {
    const url = $("aradSubtitleURL").value.trim();
    const player = $("aradVideoPlayer");

    if (!url) {
      alert("آدرس زیرنویس را وارد کن.");
      return;
    }

    try {
      if (new URL(url).protocol !== "https:") {
        throw new Error("HTTPS required");
      }
    } catch {
      alert("آدرس زیرنویس HTTPS معتبر وارد کن.");
      return;
    }

    player.querySelectorAll("track").forEach(t => t.remove());

    const track = document.createElement("track");
    track.kind = "subtitles";
    track.label = "فارسی";
    track.srclang = "fa";
    track.src = url;
    track.default = true;

    player.appendChild(track);

    $("aradVideoMessage").textContent =
      "زیرنویس اضافه شد.";
  });

  $("aradSaveNotes").addEventListener("click", function () {
    if (!activeKey) {
      alert("ابتدا یک درس انتخاب کن.");
      return;
    }

    const progress = getProgress();

    progress[activeKey] = progress[activeKey] || {};

    progress[activeKey].notes =
      $("aradVideoNotes").value;

    saveProgress(progress);

    $("aradVideoMessage").textContent =
      "یادداشت‌ها ذخیره شدند.";
  });

  $("aradVideoLesson").addEventListener("change", function () {
    const courseId = $("aradVideoCourse").value;

    if (!courseId || !this.value) return;

    activeKey = courseId + "_" + this.value;

    const saved = getProgress()[activeKey] || {};

    $("aradVideoNotes").value = saved.notes || "";
  });

  console.log("ARAD PART 12 READY");

})();


---

نسخه توسعه‌یافته و راهنمای راه‌اندازی: `README-FA.md`
