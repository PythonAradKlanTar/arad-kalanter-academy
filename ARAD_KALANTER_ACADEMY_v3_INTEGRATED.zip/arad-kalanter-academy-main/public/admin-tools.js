const $ = (id) => document.getElementById(id);

async function api(url, options = {}) {
  const headers = options.body instanceof FormData
    ? (options.headers || {})
    : { "Content-Type": "application/json", ...(options.headers || {}) };
  const response = await fetch(`/api${url}`, {
    credentials: "same-origin",
    ...options,
    headers
  });
  let data = {};
  try { data = await response.json(); } catch (_) {}
  if (!response.ok) throw new Error(data.error || "درخواست ناموفق بود.");
  return data;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

function showTab(id) {
  document.querySelectorAll("#app > section.panel").forEach((section) => section.classList.add("hidden"));
  $(id).classList.remove("hidden");
}

async function login() {
  try {
    const result = await api("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email: $("email").value, password: $("password").value })
    });
    if (!result.user || !["owner", "admin"].includes(result.user.role)) {
      await api("/auth/logout", { method: "POST" });
      throw new Error("این حساب دسترسی مدیریت ندارد.");
    }
    $("login").classList.add("hidden");
    $("app").classList.remove("hidden");
    await loadAll();
    await loadSubmissions();
  } catch (error) {
    $("loginMsg").textContent = error.message;
  }
}

async function logout() {
  try { await api("/auth/logout", { method: "POST" }); } finally { location.href = "/"; }
}

async function loadAll() {
  try {
    const [report, users, courses, coupons] = await Promise.all([
      api("/admin/reports"), api("/admin/users"), api("/admin/courses"), api("/admin/coupons")
    ]);
    $("students").textContent = report.students;
    $("coursesCount").textContent = report.courses;
    $("enrollments").textContent = report.enrollments;
    $("submissions").textContent = report.submissions;
    $("courseList").innerHTML = courses.map((course) => `
      <div class="item"><b>#${course.id} — ${escapeHtml(course.title)}</b>
      <span class="tag">${course.published ? "منتشرشده" : "پیش‌نویس"}</span>
      <button class="secondary" onclick="selectCourse(${course.id})">مدیریت فصل‌ها</button>
      <button class="secondary" onclick="editCourse(${course.id})">ویرایش</button>
      <button class="danger" onclick="deleteCourse(${course.id})">حذف دوره</button></div>`).join("") || "هنوز دوره‌ای ایجاد نشده است.";
    $("courseSelect").innerHTML = '<option value="">انتخاب دوره</option>' + courses.map((course) =>
      `<option value="${course.id}">#${course.id} — ${escapeHtml(course.title)}</option>`).join("");
    $("userList").innerHTML = users.map((user) => `
      <div class="item"><b>#${user.id} — ${escapeHtml(user.name)}</b> — ${escapeHtml(user.email)}
      <span class="tag">${escapeHtml(user.role)}</span> <span class="tag">${user.active ? "فعال" : "غیرفعال"}</span>
      ${user.role === "owner" ? "" : `<div class="row"><button class="secondary" onclick="changeRole(${user.id},'${user.role === "admin" ? "student" : "admin"}')">${user.role === "admin" ? "تبدیل به دانشجو" : "ارتقا به مدیر فرعی"}</button>
      <button class="secondary" onclick="changeActive(${user.id},${user.active ? "false" : "true"})">${user.active ? "غیرفعال‌سازی" : "فعال‌سازی"}</button></div>`}</div>`).join("");
    $("activity").innerHTML = report.recentActivity.map((item) => `
      <div class="item">${escapeHtml(item.created_at)} — ${escapeHtml(item.name || "حساب حذف‌شده")} —
      <b>${escapeHtml(item.action)}</b> <small>${escapeHtml(item.detail)}</small></div>`).join("") || "فعالیتی ثبت نشده است.";
    $("couponList").innerHTML = coupons.map((coupon) => `<div class="item">${escapeHtml(coupon.code)} — ${coupon.percent_off}% — ${coupon.uses} بار استفاده</div>`).join("");
  } catch (error) { alert(error.message); }
}

async function selectCourse(id) {
  $("courseSelect").value = String(id);
  await loadOutline();
  showTab("coursesTab");
}

async function createCourse() {
  try {
    const result = await api("/admin/courses", {
      method: "POST",
      body: JSON.stringify({
        title: $("courseTitle").value.trim(), description: $("courseDesc").value,
        price: Number($("coursePrice").value || 0), published: $("coursePublished").value === "1"
      })
    });
    alert(`دوره ساخته شد. شناسه: ${result.id}`);
    $("courseTitle").value = "";
    await loadAll();
    await selectCourse(result.id);
  } catch (error) { alert(error.message); }
}

async function loadOutline() {
  const courseId = $("courseSelect").value;
  if (!courseId) return;
  try {
    const data = await api(`/admin/courses/${courseId}/outline`);
    $("chapterSelect").innerHTML = '<option value="">انتخاب فصل</option>' + data.chapters.map((chapter) =>
      `<option value="${chapter.id}">#${chapter.id} — ${escapeHtml(chapter.title)}</option>`).join("");
    $("outline").innerHTML = data.chapters.map((chapter) => `
      <div class="item"><b>فصل #${chapter.id}: ${escapeHtml(chapter.title)}</b>
      <button class="secondary" onclick="renameChapter(${chapter.id})">تغییر نام فصل</button>
      <button class="danger" onclick="deleteChapter(${chapter.id})">حذف فصل</button>
      ${chapter.lessons.map((lesson) => `<div class="item">جلسه #${lesson.id}: ${escapeHtml(lesson.title)} — ${lesson.has_video ? "ویدئو دارد" : "بدون ویدئو"}
      <button class="secondary" onclick="renameLesson(${lesson.id})">تغییر نام جلسه</button>
      <button class="danger" onclick="deleteLesson(${lesson.id})">حذف جلسه</button></div>`).join("")}</div>`).join("") || "هنوز فصلی ساخته نشده است.";
  } catch (error) { alert(error.message); }
}

async function createChapter() {
  const courseId = $("courseSelect").value;
  if (!courseId) return alert("ابتدا دوره را انتخاب کنید.");
  try {
    const result = await api(`/admin/courses/${courseId}/chapters`, {
      method: "POST", body: JSON.stringify({ title: $("chapterTitle").value, sortOrder: Number($("chapterOrder").value || 0) })
    });
    alert(`فصل ساخته شد. شناسه: ${result.id}`);
    $("chapterTitle").value = "";
    await loadOutline();
    $("chapterSelect").value = String(result.id);
  } catch (error) { alert(error.message); }
}

async function createLesson() {
  const chapterId = $("chapterSelect").value;
  if (!chapterId) return alert("ابتدا فصل را انتخاب کنید.");
  try {
    const result = await api(`/admin/chapters/${chapterId}/lessons`, {
      method: "POST",
      body: JSON.stringify({
        title: $("lessonTitle").value, description: $("lessonDesc").value,
        durationSeconds: Number($("lessonDuration").value || 0),
        isFree: $("lessonFree").value === "1", sortOrder: Number($("lessonOrder").value || 0),
        videoUrl: $("lessonVideoUrl").value.trim()
      })
    });
    alert(`جلسه ساخته شد. شناسه جلسه برای آپلود ویدئو: ${result.id}`);
    $("videoLesson").value = result.id;
    $("lessonTitle").value = "";
    await loadOutline();
    showTab("videoTab");
  } catch (error) { alert(error.message); }
}

async function deleteChapter(id) {
  if (!confirm("این فصل و تمام جلسات آن حذف شود؟")) return;
  try { await api(`/admin/chapters/${id}`, { method: "DELETE" }); await loadOutline(); }
  catch (error) { alert(error.message); }
}

async function deleteLesson(id) {
  if (!confirm("این جلسه حذف شود؟")) return;
  try { await api(`/admin/lessons/${id}`, { method: "DELETE" }); await loadOutline(); }
  catch (error) { alert(error.message); }
}

async function uploadVideo() {
  try {
    const file = $("videoFile").files[0];
    if (!file) throw new Error("ابتدا فایل ویدئو را انتخاب کنید.");
    const body = new FormData();
    body.append("video", file);
    const result = await api(`/admin/lessons/${$("videoLesson").value}/video`, { method: "POST", body });
    $("videoStatus").textContent = `ویدئو متصل شد؛ ذخیره‌سازی: ${result.storage}`;
    $("videoFile").value = "";
    await loadOutline();
  } catch (error) { $("videoStatus").textContent = error.message; }
}

async function loadSubmissions() {
  try {
    const submissions = await api("/admin/submissions");
    $("submissionList").innerHTML = submissions.map((item) => `
      <div class="item"><b>#${item.id} — ${escapeHtml(item.student_name)}</b> — ${escapeHtml(item.lesson_title)}
      <a href="/api/admin/submissions/${item.id}/file">دریافت فایل تکلیف</a>
      <div class="row"><input id="grade-${item.id}" type="number" min="0" max="100" placeholder="نمره از ۱۰۰" value="${item.grade ?? ""}">
      <input id="feedback-${item.id}" placeholder="بازخورد" value="${escapeHtml(item.feedback)}"></div>
      <button onclick="gradeSubmission(${item.id})">ثبت نمره و بازخورد</button></div>`).join("") || "تکلیفی ارسال نشده است.";
  } catch (error) { alert(error.message); }
}

async function gradeSubmission(id) {
  try {
    await api(`/admin/submissions/${id}/grade`, {
      method: "PUT", body: JSON.stringify({ grade: Number($(`grade-${id}`).value), feedback: $(`feedback-${id}`).value })
    });
    alert("نمره و بازخورد ذخیره شد.");
  } catch (error) { alert(error.message); }
}

async function notice() {
  try {
    const result = await api("/admin/announcements", {
      method: "POST", body: JSON.stringify({ title: $("noticeTitle").value, body: $("noticeBody").value })
    });
    $("noticeStatus").textContent = `اطلاعیه برای ${result.recipients} دانشجو ارسال شد.`;
  } catch (error) { $("noticeStatus").textContent = error.message; }
}

async function coupon() {
  try {
    await api("/admin/coupons", {
      method: "POST", body: JSON.stringify({ code: $("couponCode").value, percentOff: Number($("couponPercent").value), expiresAt: $("couponExpiry").value || null, maxUses: Number($("couponUses").value || 0) || null })
    });
    alert("کد تخفیف ساخته شد.");
    await loadAll();
  } catch (error) { alert(error.message); }
}

async function changeRole(id, role) {
  if (!confirm("نقش این حساب تغییر کند؟")) return;
  try { await api(`/admin/users/${id}/role`, { method: "PUT", body: JSON.stringify({ role }) }); await loadAll(); }
  catch (error) { alert(error.message); }
}

async function changeActive(id, active) {
  try { await api(`/admin/users/${id}/active`, { method: "PUT", body: JSON.stringify({ active }) }); await loadAll(); }
  catch (error) { alert(error.message); }
}

async function enrollUser() {
  try {
    await api("/admin/enrollments", {
      method: "POST", body: JSON.stringify({ userId: Number($("enrollUserId").value), courseId: Number($("enrollCourseId").value) })
    });
    alert("دانشجو در دوره ثبت‌نام شد.");
    await loadAll();
  } catch (error) { alert(error.message); }
}

async function backup() {
  try { const result = await api("/admin/backup", { method: "POST" }); alert(`پشتیبان ساخته شد: ${result.file}`); }
  catch (error) { alert(error.message); }
}

(async function restoreSession() {
  try {
    const result = await api("/auth/me");
    if (result.user && ["owner", "admin"].includes(result.user.role)) {
      $("login").classList.add("hidden");
      $("app").classList.remove("hidden");
      await loadAll();
      await loadSubmissions();
    }
  } catch (_) {}
})();

async function editCourse(id){
  try{
    const courses=await api("/admin/courses");
    const course=courses.find(item=>item.id===id);
    if(!course)return alert("دوره پیدا نشد.");
    const newTitle=prompt("عنوان دوره",course.title);if(newTitle===null)return;
    const newDescription=prompt("توضیحات دوره",course.description);if(newDescription===null)return;
    const newPrice=prompt("قیمت به ریال",course.price);if(newPrice===null)return;
    const newPublished=prompt("وضعیت انتشار: 1 برای منتشرشده، 0 برای پیش‌نویس",course.published?"1":"0");if(newPublished===null)return;
    await api(`/admin/courses/${id}`,{method:"PUT",body:JSON.stringify({title:newTitle,description:newDescription,price:Number(newPrice),published:newPublished==="1"})});
    await loadAll();
  }catch(error){alert(error.message);}
}
async function deleteCourse(id){
  if(!confirm("دوره و تمام فصل‌ها، جلسات و پیشرفت وابسته حذف شود؟"))return;
  try{await api(`/admin/courses/${id}`,{method:"DELETE"});await loadAll();$("outline").textContent="دوره حذف شد.";}
  catch(error){alert(error.message);}
}
async function renameChapter(id){
  const title=prompt("عنوان جدید فصل");if(title===null)return;
  try{await api(`/admin/chapters/${id}/title`,{method:"PATCH",body:JSON.stringify({title})});await loadOutline();}
  catch(error){alert(error.message);}
}
async function renameLesson(id){
  const title=prompt("عنوان جدید جلسه");if(title===null)return;
  try{await api(`/admin/lessons/${id}/title`,{method:"PATCH",body:JSON.stringify({title})});await loadOutline();}
  catch(error){alert(error.message);}
}
