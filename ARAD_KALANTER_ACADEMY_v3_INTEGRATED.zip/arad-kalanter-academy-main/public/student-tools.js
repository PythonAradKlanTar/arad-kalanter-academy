const $ = (id) => document.getElementById(id);
let currentLesson = null;
let progressTimer = null;

async function api(url, options = {}) {
  const headers = options.body instanceof FormData ? (options.headers || {}) : { "Content-Type": "application/json", ...(options.headers || {}) };
  const response = await fetch(`/api${url}`, { credentials: "same-origin", ...options, headers });
  let data = {};
  try { data = await response.json(); } catch (_) {}
  if (!response.ok) throw new Error(data.error || "درخواست ناموفق بود.");
  return data;
}

function showAuth(mode) {
  $("loginForm").classList.toggle("hidden", mode !== "login");
  $("registerForm").classList.toggle("hidden", mode !== "register");
  $("authStatus").textContent = "";
}

async function login() {
  try {
    const user = await api("/auth/login", { method: "POST", body: JSON.stringify({ email: $("loginEmail").value, password: $("loginPassword").value }) });
    await enterApp(user.user);
  } catch (error) { $("authStatus").textContent = error.message; }
}

async function register() {
  try {
    const user = await api("/auth/register", { method: "POST", body: JSON.stringify({ name: $("registerName").value, email: $("registerEmail").value, password: $("registerPassword").value }) });
    await enterApp(user.user);
  } catch (error) { $("authStatus").textContent = error.message; }
}

async function enterApp(user) {
  $("auth").classList.add("hidden");
  $("studentApp").classList.remove("hidden");
  $("welcome").textContent = `سلام ${user.name}`;
  $("userRole").textContent = `شناسه دانشجو: ${user.id} · نقش: ${user.role}`;
  await refreshDashboard();
}

async function logout() {
  try { await api("/auth/logout", { method: "POST" }); } finally { location.reload(); }
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" })[char]);
}

async function refreshDashboard() {
  try {
    const [courses, progress, messages, enrollments] = await Promise.all([
      api("/courses"), api("/my/progress"), api("/my/messages"), api("/my/enrollments")
    ]);
    const enrolledIds = new Set(enrollments.map((item) => item.course_id));
    $("courses").innerHTML = courses.map((course) => `
      <article class="lesson"><b>${escapeHtml(course.title)}</b><p>${escapeHtml(course.description)}</p>
      <small>قیمت: ${Number(course.price).toLocaleString("fa-IR")} ریال · ${course.chapter_count} فصل</small>
      <button onclick="openCourse(${course.id})">مشاهده فصل‌ها</button>
      ${enrolledIds.has(course.id) ? '<span>ثبت‌نام‌شده</span>' : course.price === 0 ? `<button class="secondary" onclick="enrollFree(${course.id})">ثبت‌نام رایگان</button>` : '<span class="muted">نیازمند خرید</span>'}
      </article>`).join("") || "در حال حاضر دوره منتشرشده‌ای وجود ندارد.";
    $("progress").innerHTML = progress.map((item) => `
      <div class="lesson"><b>${escapeHtml(item.lesson_title)}</b><br>${item.completed ? "تکمیل‌شده" : `${Number(item.seconds_watched).toLocaleString("fa-IR")} ثانیه تماشا`}</div>`).join("") || "هنوز پیشرفتی ثبت نشده است.";
    $("messages").innerHTML = messages.map((item) => `
      <article class="lesson"><b>${escapeHtml(item.title)}</b><p>${escapeHtml(item.body)}</p><small>${escapeHtml(item.created_at)}</small>
      ${item.read_at ? "" : `<button class="secondary" onclick="markMessageRead(${item.id})">علامت‌گذاری به‌عنوان خوانده‌شده</button>`}</article>`).join("") || "پیامی ندارید.";
  } catch (error) { alert(error.message); }
}

async function enrollFree(courseId) {
  try { await api(`/courses/${courseId}/enroll`, { method: "POST" }); alert("ثبت‌نام رایگان انجام شد."); await refreshDashboard(); await openCourse(courseId); }
  catch (error) { alert(error.message); }
}

async function openCourse(courseId) {
  try {
    const data = await api(`/courses/${courseId}/content`);
    $("courseHeading").textContent = data.course.title;
    $("courseContent").innerHTML = data.chapters.map((chapter) => `
      <div class="lesson"><h3>${escapeHtml(chapter.title)}</h3>
      ${chapter.lessons.map((lesson) => `
        <div class="lesson ${lesson.locked ? "locked" : ""}"><b>${escapeHtml(lesson.title)}</b>
        <small> · ${Math.ceil(lesson.duration_seconds / 60)} دقیقه ${lesson.locked ? "· قفل‌شده" : ""}</small>
        ${lesson.locked ? "" : `<p>${escapeHtml(lesson.description)}</p>`}
        ${lesson.locked ? "" : lesson.has_video ? `<button onclick="playLesson(${lesson.id})">پخش ویدئو</button>` : '<span class="muted">ویدئو هنوز توسط مدیر بارگذاری نشده است.</span>'}</div>`).join("")}
      </div>`).join("") || "این دوره هنوز جلسه‌ای ندارد.";
  } catch (error) { alert(error.message); }
}

async function playLesson(id) {
  currentLesson = id;
  $("nowPlaying").textContent = `در حال پخش جلسه شماره ${id}`;
  $("assignmentLesson").textContent = `ارسال تکلیف برای جلسه ${id}`;
  $("externalVideo").classList.add("hidden");
  const player = $("player");
  player.src = `/api/lessons/${id}/video`;
  player.load();
  player.play().catch(() => {});
}

function saveCurrentProgress(completed = false) {
  if (!currentLesson) return;
  const seconds = Math.floor($("player").currentTime || 0);
  api("/progress", { method: "POST", body: JSON.stringify({ lessonId: currentLesson, secondsWatched: seconds, completed }) }).catch(console.error);
}

$("player").addEventListener("timeupdate", () => {
  if (progressTimer) return;
  progressTimer = setTimeout(() => { saveCurrentProgress(false); progressTimer = null; }, 10000);
});
$("player").addEventListener("ended", () => saveCurrentProgress(true));

function markLessonComplete() {
  if (!currentLesson) return alert("ابتدا یک جلسه را انتخاب کنید.");
  saveCurrentProgress(true);
  alert("تکمیل جلسه ثبت شد.");
}

async function submitWork() {
  try {
    if (!currentLesson) throw new Error("ابتدا یک جلسه را انتخاب کنید.");
    const file = $("assignmentFile").files[0];
    if (!file) throw new Error("فایل تکلیف را انتخاب کنید.");
    const body = new FormData();
    body.append("file", file);
    body.append("note", $("assignmentNote").value);
    const response = await fetch(`/api/lessons/${currentLesson}/submit`, { method: "POST", body, credentials: "same-origin" });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "ارسال تکلیف ناموفق بود.");
    $("submitStatus").textContent = "تکلیف با موفقیت ارسال شد.";
    $("assignmentFile").value = "";
  } catch (error) { $("submitStatus").textContent = error.message; }
}

async function markMessageRead(id) {
  try { await api(`/my/messages/${id}/read`, { method: "PUT" }); await refreshDashboard(); }
  catch (error) { alert(error.message); }
}

(async function restoreSession() {
  try {
    const result = await api("/auth/me");
    if (result.user) await enterApp(result.user);
  } catch (_) {}
})();
